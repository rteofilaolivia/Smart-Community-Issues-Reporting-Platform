import api from './api';

export const analyticsService = {
  async getOverview() {
    const response = await api.get('/analytics/overview/');
    return response.data;
  },

  async getUserStats() {
    const response = await api.get('/analytics/user-stats/');
    return response.data;
  },

  async getCategoryBreakdown() {
    const response = await api.get('/analytics/by-category/');
    return response.data;
  },

  async getStatusBreakdown() {
    const response = await api.get('/analytics/by-status/');
    return response.data;
  },

  async getActivityFeed() {
    const response = await api.get('/analytics/activity-feed/');
    return response.data;
  },
};
