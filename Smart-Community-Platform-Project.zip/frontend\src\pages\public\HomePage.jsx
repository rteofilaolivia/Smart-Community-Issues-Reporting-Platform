import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Building2, 
  PlusCircle, 
  Compass, 
  CheckCircle2, 
  Clock, 
  ShieldCheck, 
  ArrowRight, 
  Sparkles,
  Camera,
  Layers,
  PhoneCall,
  Activity,
  AlertTriangle,
  Lightbulb,
  Trash2,
  Droplets,
  Waves,
  Trees,
  Zap,
  HelpCircle
} from 'lucide-react';
import { analyticsService } from '../../services/analyticsService';
import { issueService } from '../../services/issueService';
import { IssueCard } from '../../components/issues/IssueCard';

export const HomePage = () => {
  const [stats, setStats] = useState({
    total_issues: 0,
    resolved_issues: 0,
    pending_issues: 0,
    resolution_rate: 0,
  });
  const [recentIssues, setRecentIssues] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadHomeData = async () => {
      try {
        const [statsData, issuesData, catsData] = await Promise.all([
          analyticsService.getOverview(),
          issueService.getIssues({ ordering: '-created_at' }),
          issueService.getCategories(),
        ]);
        setStats(statsData);
        setRecentIssues((issuesData.results || issuesData).slice(0, 3));
        setCategories(catsData);
      } catch (err) {
        console.error('Failed to load home page data:', err);
      } finally {
        setLoading(false);
      }
    };
    loadHomeData();
  }, []);

  const getCategoryIcon = (slug) => {
    switch (slug) {
      case 'roads-potholes': return <AlertTriangle className="w-5 h-5 text-rose-500" />;
      case 'streetlights': return <Lightbulb className="w-5 h-5 text-amber-500" />;
      case 'garbage-waste': return <Trash2 className="w-5 h-5 text-emerald-500" />;
      case 'water-supply': return <Droplets className="w-5 h-5 text-blue-500" />;
      case 'drainage': return <Waves className="w-5 h-5 text-cyan-500" />;
      case 'parks-public-spaces': return <Trees className="w-5 h-5 text-green-500" />;
      case 'electricity': return <Zap className="w-5 h-5 text-amber-600" />;
      default: return <HelpCircle className="w-5 h-5 text-slate-500" />;
    }
  };

  return (
    <div className="space-y-16 pb-16">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 text-white py-20 px-4 sm:px-6 lg:px-8 overflow-hidden rounded-b-3xl shadow-xl">
        {/* Glow backdrop subtle effect */}
        <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" />

        <div className="max-w-5xl mx-auto text-center relative z-10 space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold tracking-wide uppercase backdrop-blur-sm">
            <Sparkles className="w-3.5 h-3.5" />
            Next-Gen Civic Engagement Platform
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight">
            Smart Community <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-300">
              Issues Reporting Platform
            </span>
          </h1>

          <p className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto font-normal leading-relaxed">
            Empowering residents to report municipal problems—from potholes and dark streetlights to water leaks and waste accumulation. Direct transparency from complaint to resolution.
          </p>

          {/* Action CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 pt-4">
            <Link
              to="/report"
              className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 active:bg-emerald-700 text-white font-bold text-sm transition-all shadow-lg hover:shadow-emerald-500/25 flex items-center justify-center gap-2"
            >
              <PlusCircle className="w-5 h-5" />
              Report an Issue Now
            </Link>

            <Link
              to="/feed"
              className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-200 border border-slate-700 font-semibold text-sm transition-all flex items-center justify-center gap-2"
            >
              <Compass className="w-5 h-5" />
              Explore Community Issues
            </Link>
          </div>

          {/* Live Metrics Ribbon */}
          <div className="pt-10 grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-4xl mx-auto border-t border-slate-700/60 mt-12 text-left">
            <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-700/40">
              <span className="text-xs text-slate-400 font-medium block">Total Reports</span>
              <span className="text-2xl sm:text-3xl font-extrabold text-white">
                {stats.total_issues}
              </span>
            </div>
            <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-700/40">
              <span className="text-xs text-emerald-400 font-medium block">Issues Resolved</span>
              <span className="text-2xl sm:text-3xl font-extrabold text-emerald-400">
                {stats.resolved_issues}
              </span>
            </div>
            <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-700/40">
              <span className="text-xs text-amber-400 font-medium block">In Triage / Active</span>
              <span className="text-2xl sm:text-3xl font-extrabold text-amber-400">
                {stats.pending_issues}
              </span>
            </div>
            <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-700/40">
              <span className="text-xs text-blue-400 font-medium block">Resolution Rate</span>
              <span className="text-2xl sm:text-3xl font-extrabold text-blue-400">
                {stats.resolution_rate}%
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">
            Frictionless Process
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 mt-1">
            How It Works in 3 Simple Steps
          </h2>
          <p className="text-sm text-slate-500 mt-2">
            A modernized, transparent workflow connecting citizens with municipal response crews.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="card-container p-6 text-center space-y-4 hover:border-emerald-200 transition-all">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-xl border border-emerald-100">
              <Camera className="w-7 h-7" />
            </div>
            <h3 className="font-bold text-base text-slate-900">1. Spot & Report</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Take a quick photo, select the problem category, pin the street address, and describe the civic issue.
            </p>
          </div>

          <div className="card-container p-6 text-center space-y-4 hover:border-emerald-200 transition-all">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-xl border border-blue-100">
              <ShieldCheck className="w-7 h-7" />
            </div>
            <h3 className="font-bold text-base text-slate-900">2. Authority Triage & Dispatch</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Municipal authorities review the ticket, assign it to the responsible department, and dispatch repair crews.
            </p>
          </div>

          <div className="card-container p-6 text-center space-y-4 hover:border-emerald-200 transition-all">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center font-bold text-xl border border-purple-100">
              <CheckCircle2 className="w-7 h-7" />
            </div>
            <h3 className="font-bold text-base text-slate-900">3. Track & Verify Resolution</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Receive automatic status notifications and view timestamped field notes as your reported issue gets resolved.
            </p>
          </div>
        </div>
      </section>

      {/* Civic Categories Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">
              Issue Classifications
            </span>
            <h2 className="text-2xl font-bold text-slate-900 mt-1">
              Civic Categories Covered
            </h2>
          </div>
          <Link
            to="/report"
            className="text-xs font-semibold text-emerald-600 hover:text-emerald-700 flex items-center gap-1"
          >
            Submit an issue in any category <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {categories.map((cat) => (
            <Link
              key={cat.slug}
              to={`/feed?category=${cat.slug}`}
              className="card-container p-4 hover:border-slate-300 hover:shadow-md transition-all flex items-start gap-3.5 group"
            >
              <div className="p-2.5 rounded-xl bg-slate-50 group-hover:bg-emerald-50 transition-colors">
                {getCategoryIcon(cat.slug)}
              </div>
              <div className="min-w-0">
                <h4 className="font-semibold text-sm text-slate-900 group-hover:text-emerald-700 transition-colors">
                  {cat.name}
                </h4>
                <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                  {cat.description || 'Civic infrastructure category'}
                </p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Recent Issues Preview */}
      {recentIssues.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-4 mb-8">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">
                Live Community Feed
              </span>
              <h2 className="text-2xl font-bold text-slate-900 mt-1">
                Recent Public Reports
              </h2>
            </div>
            <Link
              to="/feed"
              className="btn-secondary text-xs"
            >
              View All Issues
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {recentIssues.map((issue) => (
              <IssueCard key={issue.id} issue={issue} />
            ))}
          </div>
        </section>
      )}

      {/* Callout Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-emerald-600 text-white rounded-3xl p-8 sm:p-12 flex flex-col sm:flex-row items-center justify-between gap-8 shadow-lg">
          <div className="space-y-3 text-center sm:text-left">
            <h3 className="text-2xl sm:text-3xl font-extrabold">
              Notice an issue in your neighborhood?
            </h3>
            <p className="text-sm text-emerald-100 max-w-xl">
              Don't wait for someone else to report it. It takes less than 60 seconds to submit a report and notify municipal response teams.
            </p>
          </div>

          <Link
            to="/report"
            className="px-6 py-3.5 bg-white text-emerald-800 hover:bg-emerald-50 active:bg-emerald-100 font-bold text-sm rounded-xl transition-all shadow-md flex-shrink-0"
          >
            Report an Issue Now
          </Link>
        </div>
      </section>
    </div>
  );
};
