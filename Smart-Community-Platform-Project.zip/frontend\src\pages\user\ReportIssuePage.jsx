import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { 
  Building2, 
  Send, 
  AlertCircle, 
  CheckCircle2, 
  ArrowLeft, 
  HelpCircle,
  AlertTriangle,
  Lightbulb,
  Trash2,
  Droplets,
  Waves,
  Trees,
  Zap
} from 'lucide-react';
import { issueService } from '../../services/issueService';
import { useToast } from '../../context/ToastContext';
import { LocationPicker } from '../../components/issues/LocationPicker';
import { EvidenceUploader } from '../../components/issues/EvidenceUploader';
import { LoadingSpinner } from '../../components/common/LoadingSpinner';

export const ReportIssuePage = () => {
  const navigate = useNavigate();
  const { success, error } = useToast();

  const [categories, setCategories] = useState([]);
  const [loadingCats, setLoadingCats] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: '',
    priority: 'medium',
    location: '',
    latitude: null,
    longitude: null,
  });
  const [selectedImage, setSelectedImage] = useState(null);

  useEffect(() => {
    const loadCategories = async () => {
      try {
        const cats = await issueService.getCategories();
        setCategories(cats);
        if (cats.length > 0) {
          setFormData((prev) => ({ ...prev, category: cats[0].id }));
        }
      } catch (err) {
        console.error('Failed to load categories:', err);
      } finally {
        setLoadingCats(false);
      }
    };
    loadCategories();
  }, []);

  const getCategoryIcon = (slug) => {
    switch (slug) {
      case 'roads-potholes': return <AlertTriangle className="w-4 h-4 text-rose-500" />;
      case 'streetlights': return <Lightbulb className="w-4 h-4 text-amber-500" />;
      case 'garbage-waste': return <Trash2 className="w-4 h-4 text-emerald-500" />;
      case 'water-supply': return <Droplets className="w-4 h-4 text-blue-500" />;
      case 'drainage': return <Waves className="w-4 h-4 text-cyan-500" />;
      case 'parks-public-spaces': return <Trees className="w-4 h-4 text-green-500" />;
      case 'electricity': return <Zap className="w-4 h-4 text-amber-600" />;
      default: return <HelpCircle className="w-4 h-4 text-slate-500" />;
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMessage('');

    if (formData.title.trim().length < 5) {
      setErrorMessage('Title must be at least 5 characters long.');
      return;
    }
    if (formData.description.trim().length < 10) {
      setErrorMessage('Description must be at least 10 characters long.');
      return;
    }
    if (!formData.location.trim()) {
      setErrorMessage('Please provide the street address or location.');
      return;
    }
    if (!formData.category) {
      setErrorMessage('Please select an issue category.');
      return;
    }

    setSubmitting(true);

    const payload = new FormData();
    payload.append('title', formData.title.trim());
    payload.append('description', formData.description.trim());
    payload.append('category', formData.category);
    payload.append('priority', formData.priority);
    payload.append('location', formData.location.trim());

    if (formData.latitude !== null && formData.latitude !== undefined) {
      payload.append('latitude', formData.latitude);
    }
    if (formData.longitude !== null && formData.longitude !== undefined) {
      payload.append('longitude', formData.longitude);
    }
    if (selectedImage) {
      payload.append('image', selectedImage);
    }

    try {
      const response = await issueService.createIssue(payload);
      success('Civic issue reported successfully! Authorities have been notified.');
      navigate(`/issues/${response.id}`);
    } catch (err) {
      console.error('Failed to submit issue:', err);
      const resData = err.response?.data;
      if (typeof resData === 'object' && resData !== null) {
        const firstKey = Object.keys(resData)[0];
        setErrorMessage(`${firstKey}: ${resData[firstKey]}`);
      } else {
        setErrorMessage('Failed to report issue. Please ensure you are logged in.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  if (loadingCats) {
    return <LoadingSpinner fullPage message="Loading report form..." />;
  }

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Top Breadcrumb */}
      <Link
        to="/dashboard"
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900"
      >
        <ArrowLeft className="w-4 h-4" /> Back to Dashboard
      </Link>

      {/* Form Container */}
      <div className="card-container p-6 sm:p-10 space-y-8">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Report a Community Issue
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Provide details about the civic problem. Your ticket will be dispatched to the responsible municipal department.
          </p>
        </div>

        {errorMessage && (
          <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2.5">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Issue Title */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Issue Title *
            </label>
            <input
              type="text"
              required
              minLength={5}
              maxLength={200}
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder="e.g. Deep pothole on corner of 5th Ave and Main St"
              className="input-field"
            />
          </div>

          {/* Category Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
              Select Category *
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {categories.map((cat) => {
                const isSelected = String(formData.category) === String(cat.id);
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setFormData({ ...formData, category: cat.id })}
                    className={`p-3 rounded-xl border text-left flex items-center gap-2.5 transition-all text-xs font-medium ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-900 shadow-sm ring-1 ring-emerald-600'
                        : 'border-slate-200 hover:border-slate-300 bg-white text-slate-700'
                    }`}
                  >
                    <div className="p-1.5 rounded-lg bg-white border border-slate-100 shadow-xs">
                      {getCategoryIcon(cat.slug)}
                    </div>
                    <span className="truncate">{cat.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Priority Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
              Urgency / Priority Level
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'low', label: 'Low', desc: 'Cosmetic / Non-critical' },
                { id: 'medium', label: 'Medium', desc: 'Standard turnaround' },
                { id: 'high', label: 'High', desc: 'Impacts traffic / daily flow' },
                { id: 'urgent', label: 'Urgent', desc: 'Safety hazard / Emergency' },
              ].map((p) => {
                const isSelected = formData.priority === p.id;
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setFormData({ ...formData, priority: p.id })}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-900 ring-1 ring-emerald-600'
                        : 'border-slate-200 hover:border-slate-300 bg-white text-slate-700'
                    }`}
                  >
                    <span className="block text-xs font-bold capitalize">{p.label}</span>
                    <span className="block text-[10px] text-slate-500 mt-0.5">{p.desc}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Detailed Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Detailed Description *
            </label>
            <textarea
              rows={4}
              required
              minLength={10}
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Describe what happened, how long the issue has persisted, and any specific safety concerns..."
              className="input-field"
            />
          </div>

          {/* Location & GPS Picker */}
          <LocationPicker
            location={formData.location}
            latitude={formData.latitude}
            longitude={formData.longitude}
            onChange={({ location, latitude, longitude }) =>
              setFormData({ ...formData, location, latitude, longitude })
            }
          />

          {/* Photo Evidence Upload */}
          <EvidenceUploader
            onFileSelect={(file) => setSelectedImage(file)}
          />

          {/* Submit Button */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
            <Link to="/dashboard" className="btn-secondary">
              Cancel
            </Link>
            <button
              type="submit"
              disabled={submitting}
              className="btn-primary py-3 px-6 text-sm flex items-center gap-2"
            >
              <Send className="w-4 h-4" />
              {submitting ? 'Submitting Report...' : 'Submit Civic Report'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
