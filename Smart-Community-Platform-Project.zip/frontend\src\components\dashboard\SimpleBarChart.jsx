import React from 'react';

export const SimpleBarChart = ({ data = [], title = 'Issues by Category' }) => {
  if (!data || data.length === 0) {
    return (
      <div className="card-container p-6">
        <h4 className="font-bold text-sm text-slate-800 mb-4">{title}</h4>
        <div className="text-center py-8 text-xs text-slate-400">No chart data available</div>
      </div>
    );
  }

  const maxVal = Math.max(...data.map((d) => d.total_issues || 0), 1);

  return (
    <div className="card-container p-6">
      <h4 className="font-bold text-sm text-slate-800 mb-5">{title}</h4>
      <div className="space-y-3.5">
        {data.map((item) => {
          const count = item.total_issues || 0;
          const percentage = Math.round((count / maxVal) * 100);

          return (
            <div key={item.id || item.name} className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium text-slate-700 truncate max-w-[200px]">
                  {item.name}
                </span>
                <span className="font-bold text-slate-900">
                  {count} <span className="text-[11px] font-normal text-slate-400">issues</span>
                </span>
              </div>

              <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-500 ease-out"
                  style={{
                    width: `${Math.max(percentage, 3)}%`,
                    backgroundColor: item.color || '#16a34a',
                  }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
