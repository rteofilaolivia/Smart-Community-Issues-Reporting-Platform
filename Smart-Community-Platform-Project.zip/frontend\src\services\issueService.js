import api from './api';

export const issueService = {
  async getIssues(params = {}) {
    const response = await api.get('/issues/', { params });
    return response.data;
  },

  async getIssue(id) {
    const response = await api.get(`/issues/${id}/`);
    return response.data;
  },

  async createIssue(formData) {
    const response = await api.post('/issues/', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  },

  async updateIssue(id, data) {
    const isFormData = data instanceof FormData;
    const response = await api.patch(`/issues/${id}/`, data, {
      headers: isFormData ? { 'Content-Type': 'multipart/form-data' } : {},
    });
    return response.data;
  },

  async deleteIssue(id) {
    const response = await api.delete(`/issues/${id}/`);
    return response.data;
  },

  async getMyReports(params = {}) {
    const response = await api.get('/issues/my_reports/', { params });
    return response.data;
  },

  async updateStatus(id, { status, notes, rejection_reason, resolution_notes }) {
    const response = await api.post(`/issues/${id}/update_status/`, {
      status,
      notes,
      rejection_reason,
      resolution_notes,
    });
    return response.data;
  },

  async assignIssue(id, { assigned_department, assigned_to, notes }) {
    const response = await api.post(`/issues/${id}/assign/`, {
      assigned_department,
      assigned_to,
      notes,
    });
    return response.data;
  },

  async getCategories() {
    const response = await api.get('/categories/');
    return response.data.results || response.data;
  },

  async getComments(issueId) {
    const response = await api.get(`/issues/${issueId}/comments/`);
    return response.data;
  },

  async addComment(issueId, { text, is_internal = false }) {
    const response = await api.post(`/issues/${issueId}/comments/`, {
      text,
      is_internal,
    });
    return response.data;
  },
};
