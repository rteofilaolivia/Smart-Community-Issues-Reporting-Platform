import api from './api';

export const notificationService = {
  async getNotifications(params = {}) {
    const response = await api.get('/notifications/', { params });
    return response.data;
  },

  async markAsRead(id) {
    const response = await api.post(`/notifications/${id}/mark_read/`);
    return response.data;
  },

  async markAllAsRead() {
    const response = await api.post('/notifications/mark_all_read/');
    return response.data;
  },

  async getUnreadCount() {
    const response = await api.get('/notifications/unread_count/');
    return response.data.unread_count || 0;
  },
};
