from rest_framework import serializers
from django.utils import timezone
from accounts.serializers import UserSerializer, DepartmentSerializer
from accounts.models import Department, User
from .models import Issue, IssueCategory, IssueComment, IssueActivityLog

class IssueCategorySerializer(serializers.ModelSerializer):
    issues_count = serializers.IntegerField(source='issues.count', read_only=True)

    class Meta:
        model = IssueCategory
        fields = ['id', 'name', 'slug', 'description', 'icon', 'color', 'is_active', 'default_department', 'issues_count']


class IssueCommentSerializer(serializers.ModelSerializer):
    author_details = UserSerializer(source='author', read_only=True)

    class Meta:
        model = IssueComment
        fields = ['id', 'issue', 'author', 'author_details', 'text', 'is_internal', 'created_at']
        read_only_fields = ['id', 'author', 'created_at']


class IssueActivityLogSerializer(serializers.ModelSerializer):
    performed_by_name = serializers.SerializerMethodField()

    class Meta:
        model = IssueActivityLog
        fields = ['id', 'issue', 'performed_by', 'performed_by_name', 'action', 'old_status', 'new_status', 'notes', 'created_at']

    def get_performed_by_name(self, obj):
        if obj.performed_by:
            return obj.performed_by.get_full_name() or obj.performed_by.username
        return 'System Automation'


class IssueListSerializer(serializers.ModelSerializer):
    """
    Optimized serializer for list views, cards, and feeds.
    """
    category_name = serializers.CharField(source='category.name', read_only=True)
    category_icon = serializers.CharField(source='category.icon', read_only=True)
    category_color = serializers.CharField(source='category.color', read_only=True)
    citizen_name = serializers.SerializerMethodField()
    assigned_department_name = serializers.CharField(source='assigned_department.name', read_only=True)
    comments_count = serializers.IntegerField(source='comments.count', read_only=True)

    class Meta:
        model = Issue
        fields = [
            'id', 'title', 'description', 'category', 'category_name', 'category_icon', 'category_color',
            'status', 'priority', 'location', 'latitude', 'longitude',
            'image', 'citizen', 'citizen_name', 'assigned_department',
            'assigned_department_name', 'comments_count', 'created_at', 'updated_at'
        ]

    def get_citizen_name(self, obj):
        return obj.citizen.get_full_name() or obj.citizen.username


class IssueDetailSerializer(serializers.ModelSerializer):
    """
    Full comprehensive serializer for single issue view.
    """
    category_details = IssueCategorySerializer(source='category', read_only=True)
    citizen_details = UserSerializer(source='citizen', read_only=True)
    assigned_department_details = DepartmentSerializer(source='assigned_department', read_only=True)
    assigned_to_details = UserSerializer(source='assigned_to', read_only=True)
    comments = serializers.SerializerMethodField()
    activities = IssueActivityLogSerializer(many=True, read_only=True)

    class Meta:
        model = Issue
        fields = [
            'id', 'title', 'description', 'category', 'category_details',
            'status', 'priority', 'location', 'latitude', 'longitude',
            'image', 'citizen', 'citizen_details',
            'assigned_department', 'assigned_department_details',
            'assigned_to', 'assigned_to_details',
            'rejection_reason', 'resolution_notes', 'resolved_at',
            'comments', 'activities', 'created_at', 'updated_at'
        ]

    def get_comments(self, obj):
        request = self.context.get('request')
        comments_qs = obj.comments.all()
        # Hide internal staff notes from normal citizens
        if not request or not request.user or not (request.user.is_authenticated and request.user.is_authority):
            comments_qs = comments_qs.filter(is_internal=False)
        return IssueCommentSerializer(comments_qs, many=True, context=self.context).data


class IssueCreateUpdateSerializer(serializers.ModelSerializer):
    """
    Serializer for creating and updating issues by citizens or admins.
    """
    class Meta:
        model = Issue
        fields = [
            'id', 'title', 'description', 'category', 'priority',
            'location', 'latitude', 'longitude', 'image'
        ]

    def validate_title(self, value):
        if len(value.strip()) < 5:
            raise serializers.ValidationError("Title must be at least 5 characters long.")
        return value

    def validate_description(self, value):
        if len(value.strip()) < 10:
            raise serializers.ValidationError("Description must be at least 10 characters long.")
        return value


class IssueStatusUpdateSerializer(serializers.Serializer):
    """
    Serializer for admin/staff changing issue status.
    """
    status = serializers.ChoiceField(choices=Issue.Status.choices)
    notes = serializers.CharField(required=False, allow_blank=True, default='')
    rejection_reason = serializers.CharField(required=False, allow_blank=True, default='')
    resolution_notes = serializers.CharField(required=False, allow_blank=True, default='')

    def validate(self, attrs):
        new_status = attrs.get('status')
        if new_status == Issue.Status.REJECTED and not attrs.get('rejection_reason') and not attrs.get('notes'):
            raise serializers.ValidationError({"rejection_reason": "Please provide a reason for rejecting this issue."})
        return attrs


class IssueAssignSerializer(serializers.Serializer):
    """
    Serializer for assigning issue to department and/or specific staff member.
    """
    assigned_department = serializers.PrimaryKeyRelatedField(
        queryset=Department.objects.filter(is_active=True),
        required=False,
        allow_null=True
    )
    assigned_to = serializers.PrimaryKeyRelatedField(
        queryset=User.objects.filter(is_active=True),
        required=False,
        allow_null=True
    )
    notes = serializers.CharField(required=False, allow_blank=True, default='')
