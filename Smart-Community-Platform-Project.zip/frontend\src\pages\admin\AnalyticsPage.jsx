import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  CheckCircle2, 
  Clock, 
  Download, 
  Filter, 
  Layers,
  Building2,
  PieChart
} from 'lucide-react';
import { analyticsService } from '../../services/analyticsService';
import { LoadingSpinner } from '../../components/common/LoadingSpinner';
import { SimpleBarChart } from '../../components/dashboard/SimpleBarChart';
import { SimpleDonutChart } from '../../components/dashboard/SimpleDonutChart';

export const AnalyticsPage = () => {
  const [overview, setOverview] = useState({});
  const [categories, setCategories] = useState([]);
  const [statuses, setStatuses] = useState([]);
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadAnalytics = async () => {
      try {
        const [ov, cats, stats, acts] = await Promise.all([
          analyticsService.getOverview(),
          analyticsService.getCategoryBreakdown(),
          analyticsService.getStatusBreakdown(),
          analyticsService.getActivityFeed(),
        ]);
        setOverview(ov);
        setCategories(cats);
        setStatuses(stats);
        setActivities(acts);
      } catch (err) {
        console.error('Failed to load analytics:', err);
      } finally {
        setLoading(false);
      }
    };
    loadAnalytics();
  }, []);

  const handleExportCSV = () => {
    // Generate CSV data from category breakdown
    const headers = ['Category Name', 'Total Issues', 'Resolved Issues', 'Open Issues'];
    const rows = categories.map((c) => [c.name, c.total_issues, c.resolved_issues, c.open_issues]);
    
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `community_issues_analytics_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (loading) {
    return <LoadingSpinner fullPage message="Compiling civic analytics report..." />;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <BarChart3 className="w-5 h-5 text-emerald-600" />
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-700">
              Executive Analytics & Civic Metrics
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            Municipal Performance Report
          </h1>
        </div>

        <button
          onClick={handleExportCSV}
          className="btn-secondary text-xs flex items-center gap-1.5"
        >
          <Download className="w-4 h-4 text-emerald-600" /> Export CSV Report
        </button>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="card-container p-6 bg-gradient-to-br from-emerald-50 to-white border-emerald-200/80">
          <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider block mb-1">
            Community Resolution Rate
          </span>
          <div className="text-3xl sm:text-4xl font-extrabold text-emerald-700">
            {overview.resolution_rate}%
          </div>
          <p className="text-xs text-slate-500 mt-2">
            {overview.resolved_issues} of {overview.total_issues} reported problems resolved
          </p>
        </div>

        <div className="card-container p-6 bg-gradient-to-br from-blue-50 to-white border-blue-200/80">
          <span className="text-xs font-bold text-blue-800 uppercase tracking-wider block mb-1">
            Active Citizen Participation
          </span>
          <div className="text-3xl sm:text-4xl font-extrabold text-blue-700">
            {overview.total_citizens || 0}
          </div>
          <p className="text-xs text-slate-500 mt-2">
            Registered resident contributors across neighborhood sectors
          </p>
        </div>

        <div className="card-container p-6 bg-gradient-to-br from-purple-50 to-white border-purple-200/80">
          <span className="text-xs font-bold text-purple-800 uppercase tracking-wider block mb-1">
            Municipal Staff & Inspectors
          </span>
          <div className="text-3xl sm:text-4xl font-extrabold text-purple-700">
            {overview.total_staff || 0}
          </div>
          <p className="text-xs text-slate-500 mt-2">
            Field personnel across 8 municipal departments
          </p>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <SimpleBarChart
          data={categories}
          title="Total Reports Received by Civic Sector"
        />
        <SimpleDonutChart
          data={statuses}
          title="Overall Ticket Lifecycle Pipeline"
        />
      </div>

      {/* Category Performance Matrix Table */}
      <div className="space-y-4">
        <h3 className="font-bold text-base text-slate-900">
          Category Workload Matrix
        </h3>

        <div className="card-container overflow-hidden">
          <table className="w-full text-left text-xs text-slate-600">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-700 uppercase font-semibold text-[11px]">
              <tr>
                <th className="px-4 py-3">Category</th>
                <th className="px-4 py-3">Total Issues</th>
                <th className="px-4 py-3">Resolved Issues</th>
                <th className="px-4 py-3">Active / Open Issues</th>
                <th className="px-4 py-3">Completion Rate</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {categories.map((c) => {
                const rate = c.total_issues > 0 ? Math.round((c.resolved_issues / c.total_issues) * 100) : 0;
                return (
                  <tr key={c.id} className="hover:bg-slate-50/70">
                    <td className="px-4 py-3.5 font-bold text-slate-900 flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: c.color }} />
                      {c.name}
                    </td>
                    <td className="px-4 py-3.5 font-semibold text-slate-800">{c.total_issues}</td>
                    <td className="px-4 py-3.5 text-emerald-600 font-semibold">{c.resolved_issues}</td>
                    <td className="px-4 py-3.5 text-amber-600 font-semibold">{c.open_issues}</td>
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-2">
                        <div className="w-20 bg-slate-100 h-2 rounded-full overflow-hidden">
                          <div
                            className="bg-emerald-500 h-full rounded-full"
                            style={{ width: `${rate}%` }}
                          />
                        </div>
                        <span className="font-medium text-slate-700">{rate}%</span>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
