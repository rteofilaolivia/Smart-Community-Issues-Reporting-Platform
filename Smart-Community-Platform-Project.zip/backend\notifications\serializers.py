from rest_framework import serializers
from .models import Notification

class NotificationSerializer(serializers.ModelSerializer):
    issue_id = serializers.IntegerField(source='issue.id', read_only=True, allow_null=True)
    issue_title = serializers.CharField(source='issue.title', read_only=True, allow_null=True)

    class Meta:
        model = Notification
        fields = [
            'id', 'recipient', 'issue', 'issue_id', 'issue_title',
            'title', 'message', 'notification_type', 'is_read', 'created_at'
        ]
        read_only_fields = ['id', 'recipient', 'created_at']
