# Smart Community Issues Reporting Platform

A production-grade full-stack civic engagement and municipal issue tracking platform built with **Python Django + Django REST Framework** and **React.js + Tailwind CSS**.

The platform allows residents to report problems such as potholes, garbage accumulation, broken streetlights, water leakage, drainage problems, damaged roads, and other civic issues. Community authorities/admins can view, triage, assign, update, and resolve reported issues in real-time.

---

## 🌟 Key Features

### Citizen / Resident Experience
- 🔐 **Secure JWT Authentication**: Sign up and login with auto-refresh token support.
- 📝 **Report Civic Issues**: Submit tickets with title, description, category, street address, optional GPS coordinates, urgency level, and photo evidence.
- 📍 **Location & GPS Geocoding**: Interactive map coordinates and quick community landmark presets.
- 📸 **Photo Evidence Upload**: Integrated file upload with instant client-side preview (supports local media storage and AWS S3).
- 📊 **Resident Dashboard & Status Tracking**: Live progress tracking across lifecycle states (*Reported*, *Under Review*, *Assigned*, *In Progress*, *Resolved*, *Rejected*).
- 🔔 **In-App Notifications**: Real-time alert dropdown when authorities update issue status or post responses.
- 💬 **Community Discussion**: Public comments and transparency on reported issues.

### Municipal Authority / Admin Suite
- 🛡️ **Role-Based Access Control (RBAC)**: Distinct permissions for Citizens, Department Staff/Inspectors, and System Administrators.
- 📋 **Triage & Issue Management Center**: Multi-parameter search & filtering by Category, Status, Priority, and Department.
- 🏢 **Department Assignment**: Assign tickets to responsible municipal departments (Roads, Sanitation, Electrical, Water, Drainage, etc.) or specific field inspectors.
- 📈 **Executive Analytics Dashboard**: Real-time resolution metrics, category workload charts, and status distribution pipeline.
- 👥 **User Management & Role Promotion**: Promote residents to municipal staff or system administrators.
- 📑 **Audit Trail & Activity Log**: Timestamped immutable history of all status changes, notes, and staff actions.
- 📖 **Interactive Swagger / OpenAPI Docs**: Explore all REST endpoints directly at `/api/docs/`.

---

## 🏗️ Technology Stack

| Layer | Technology |
| :--- | :--- |
| **Frontend** | React 18, Vite, React Router DOM v6, Tailwind CSS, Lucide Icons, Axios |
| **Backend** | Python 3.10+, Django 4.2+, Django REST Framework (DRF) |
| **Authentication**| JWT (JSON Web Tokens) via `djangorestframework-simplejwt` |
| **Database** | PostgreSQL (with automatic SQLite fallback for zero-friction local setup) |
| **File Storage** | Local Media Storage / Amazon Web Services (AWS S3) via `django-storages` |
| **API Docs** | OpenAPI 3.0 / Swagger UI via `drf-spectacular` |
| **Containerization**| Docker & Docker Compose |

---

## 🔑 Pre-Configured Demo Accounts

After running the database seed command (`python manage.py seed_data`), you can instantly log in using any of the following accounts:

| Role | Username | Password | Access Privileges |
| :--- | :--- | :--- | :--- |
| **Administrator** | `admin` | `Admin@123` | Full control: triage, analytics, user roles, delete tickets |
| **Department Staff** | `john_staff` | `Staff@123` | Roads Department inspector: status updates, field notes |
| **Citizen (Jane)** | `citizen_jane` | `Citizen@123` | Resident: report issues, track tickets, view notifications |
| **Citizen (Mark)** | `citizen_mark` | `Citizen@123` | Resident: report issues, post community comments |

---

## 🚀 Beginner Step-by-Step Local Setup Guide

Follow these exact steps to run the complete platform on your local machine.

---

### Step 1: Clone or Navigate to the Project

Open PowerShell or Terminal and navigate to the project directory:

```bash
cd smart-community-platform
```

---

### Step 2: PostgreSQL Database Setup

#### Option A: Using PostgreSQL (Recommended)

1. Ensure PostgreSQL is installed on your computer.
2. Open your PostgreSQL terminal (`psql`) or pgAdmin:
   ```sql
   CREATE DATABASE smart_community_db;
   ```
3. Default credentials in `backend/.env` are:
   - Database Name: `smart_community_db`
   - User: `postgres`
   - Password: `postgres` (update to match your local PostgreSQL password)
   - Host: `localhost`
   - Port: `5432`

#### Option B: Automatic SQLite Fallback (Zero Configuration)
If you do not have PostgreSQL installed yet, simply set `USE_SQLITE=True` in `backend/.env`. The backend will automatically use SQLite without any additional setup!

---

### Step 3: Backend Setup (Django + DRF)

1. **Navigate to the backend directory:**
   ```bash
   cd backend
   ```

2. **Create a Python Virtual Environment:**
   - **Windows (PowerShell):**
     ```powershell
     python -m venv venv
     .\venv\Scripts\Activate.ps1
     ```
   - **macOS / Linux:**
     ```bash
     python3 -m venv venv
     source venv/bin/activate
     ```

3. **Install Backend Dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

4. **Configure Environment Variables:**
   Copy the example environment file:
   - **Windows:**
     ```powershell
     copy .env.example .env
     ```
   - **macOS / Linux:**
     ```bash
     cp .env.example .env
     ```

5. **Apply Database Migrations:**
   ```bash
   python manage.py makemigrations accounts issues notifications analytics
   python manage.py migrate
   ```

6. **Seed Initial Categories, Departments & Demo Data:**
   ```bash
   python manage.py seed_data
   ```

7. **Create a Superuser (Optional if using seeded `admin`):**
   ```bash
   python manage.py createsuperuser
   ```

8. **Start the Django Development Server:**
   ```bash
   python manage.py runserver 8000
   ```
   The backend API will be live at `http://127.0.0.1:8000/`.
   - Swagger API Documentation: `http://127.0.0.1:8000/api/docs/`
   - Django Admin Panel: `http://127.0.0.1:8000/admin/`

---

### Step 4: Frontend Setup (React.js + Vite)

Open a **new terminal window** and run:

1. **Navigate to the frontend directory:**
   ```bash
   cd smart-community-platform/frontend
   ```

2. **Install Node Dependencies:**
   ```bash
   npm install
   ```

3. **Configure Frontend Environment Variables:**
   - **Windows:**
     ```powershell
     copy .env.example .env
     ```
   - **macOS / Linux:**
     ```bash
     cp .env.example .env
     ```

4. **Start the React Development Server:**
   ```bash
   npm run dev
   ```
   Open your browser and visit: **`http://localhost:5173`**

---

## 🐳 Quick 1-Command Setup with Docker

If you have Docker Desktop installed, you can launch PostgreSQL, the Django Backend, and the React Frontend simultaneously with a single command:

```bash
docker-compose up --build
```

- **Frontend App**: `http://localhost`
- **Backend API**: `http://localhost:8000/api/v1/`
- **API Documentation**: `http://localhost:8000/api/docs/`

---

## ☁️ Preparing & Deploying to Amazon Web Services (AWS)

### 1. Database on AWS (Amazon RDS PostgreSQL)
1. In the AWS Management Console, navigate to **RDS** -> **Create Database**.
2. Select **PostgreSQL**, choose the Free Tier template (`db.t3.micro` or `db.t4g.micro`).
3. Set your Master Username and Password.
4. Set Public Accessibility or connect via VPC.
5. In your production `.env`, set:
   ```env
   DB_ENGINE=django.db.backends.postgresql
   DB_NAME=smart_community_db
   DB_USER=your_rds_master_user
   DB_PASSWORD=your_rds_master_password
   DB_HOST=your-rds-endpoint.amazonaws.com
   DB_PORT=5432
   ```

### 2. Evidence Image Storage on AWS S3
1. In AWS Console, create an **S3 Bucket** (e.g. `smart-community-evidence-bucket`).
2. Disable "Block all public access" or configure CloudFront CDN for media distribution.
3. Configure Bucket CORS policy:
   ```json
   [
     {
       "AllowedHeaders": ["*"],
       "AllowedMethods": ["GET", "PUT", "POST", "HEAD"],
       "AllowedOrigins": ["*"],
       "MaxAgeSeconds": 3000
     }
   ]
   ```
4. In your production backend `.env`, enable S3:
   ```env
   USE_S3=True
   AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE
   AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
   AWS_STORAGE_BUCKET_NAME=smart-community-evidence-bucket
   AWS_S3_REGION_NAME=us-east-1
   ```

### 3. Deploying Django Backend to AWS (Elastic Beanstalk or EC2 / App Runner)
- Install WSGI server: `gunicorn` is included in `requirements.txt`.
- Set `DEBUG=False` and supply a strong `SECRET_KEY`.
- Collect static files: `python manage.py collectstatic --noinput`.

### 4. Deploying React Frontend to AWS (S3 + CloudFront or AWS Amplify)
1. Build the production static bundle:
   ```bash
   cd frontend
   npm run build
   ```
2. Upload the contents of `dist/` to an S3 static website bucket or deploy directly using **AWS Amplify**.

---

## 📡 REST API Reference Summary

| Method | Endpoint | Description | Auth Required |
| :--- | :--- | :--- | :---: |
| `POST` | `/api/v1/auth/register/` | Register new resident citizen | None |
| `POST` | `/api/v1/auth/login/` | Obtain JWT access and refresh tokens | None |
| `POST` | `/api/v1/auth/token/refresh/` | Refresh expired JWT access token | None |
| `GET` | `/api/v1/auth/profile/` | Get authenticated user profile | User |
| `PATCH`| `/api/v1/auth/profile/` | Update profile information & avatar | User |
| `GET` | `/api/v1/issues/` | Explore public civic issues feed | None |
| `POST` | `/api/v1/issues/` | Report a new issue (Multipart with image) | User |
| `GET` | `/api/v1/issues/<id>/` | View complete issue details, timeline, notes | None |
| `GET` | `/api/v1/issues/my_reports/` | List issues reported by current citizen | User |
| `POST` | `/api/v1/issues/<id>/update_status/`| Update status, add resolution notes | Authority / Admin |
| `POST` | `/api/v1/issues/<id>/assign/` | Assign issue to department / personnel | Authority / Admin |
| `DELETE`| `/api/v1/issues/<id>/` | Delete inappropriate/duplicate report | Admin |
| `GET` | `/api/v1/categories/` | List all civic issue categories | None |
| `GET` | `/api/v1/notifications/` | Get user in-app notifications | User |
| `POST` | `/api/v1/notifications/<id>/mark_read/`| Mark notification as read | User |
| `POST` | `/api/v1/notifications/mark_all_read/`| Mark all notifications as read | User |
| `GET` | `/api/v1/analytics/overview/` | Platform summary KPI metrics | None |
| `GET` | `/api/v1/analytics/by-category/` | Issue counts aggregated by category | None |
| `GET` | `/api/v1/analytics/by-status/` | Issue counts aggregated by status | None |
| `GET` | `/api/v1/analytics/user-stats/` | Personal citizen metrics | User |
| `GET` | `/api/v1/auth/users/` | List registered platform users | Admin |
| `PATCH`| `/api/v1/auth/users/<id>/` | Update user role / department | Admin |

---

## 🛡️ Security Best Practices Implemented
- **JWT Protection**: Tokens stored securely, automatically refreshed via Axios response interceptors.
- **Password Hashing**: Industry-standard PBKDF2 with SHA-256 via Django Authentication.
- **File Upload Protection**: Validates file size (max 5MB) and mime-types before processing.
- **Granular Permissions**: Read-only public endpoints; protected reporting endpoints; strict staff & admin guards for destructive or triage operations.
- **CORS Headers**: Whitelisted frontend origins.
- **Credential Isolation**: Zero hardcoded secrets; 100% environment variable driven.

---

## 📄 License
This project is licensed under the MIT License.
