import React, { useState, useEffect } from 'react';
import { Users, Search, ShieldCheck, User, Building2, Check, X, Edit2 } from 'lucide-react';
import { authService } from '../../services/authService';
import { useToast } from '../../context/ToastContext';
import { LoadingSpinner } from '../../components/common/LoadingSpinner';
import { Modal } from '../../components/common/Modal';

export const UserManagementPage = () => {
  const [users, setUsers] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [roleFilter, setRoleFilter] = useState('');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  // Edit User Modal
  const [editingUser, setEditingUser] = useState(null);
  const [selectedRole, setSelectedRole] = useState('citizen');
  const [selectedDept, setSelectedDept] = useState('');
  const [isActive, setIsActive] = useState(true);
  const [saveLoading, setSaveLoading] = useState(false);

  const { success, error } = useToast();

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const params = {};
      if (roleFilter) params.role = roleFilter;
      if (search) params.search = search;
      const data = await authService.getUsers(params);
      setUsers(data.results || data);
    } catch (err) {
      console.error('Failed to load user list:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const loadDepartments = async () => {
      try {
        const depts = await authService.getDepartments();
        setDepartments(depts);
      } catch (err) {
        console.error('Failed to load departments:', err);
      }
    };
    loadDepartments();
  }, []);

  useEffect(() => {
    fetchUsers();
  }, [roleFilter]);

  const handleEditClick = (u) => {
    setEditingUser(u);
    setSelectedRole(u.role);
    setSelectedDept(u.department || '');
    setIsActive(u.is_active ?? true);
  };

  const handleSaveUser = async (e) => {
    e.preventDefault();
    setSaveLoading(true);
    try {
      await authService.updateUserRole(editingUser.id, {
        role: selectedRole,
        department: selectedRole === 'staff' ? (selectedDept || null) : null,
        is_active: isActive,
      });
      success(`Updated account roles for ${editingUser.username}.`);
      setEditingUser(null);
      fetchUsers();
    } catch (err) {
      console.error('Failed to update user:', err);
      error('Failed to update user account.');
    } finally {
      setSaveLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            User Directory & Access Control
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Manage citizen accounts, appoint municipal staff, and configure administrative roles
          </p>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="card-container p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative flex-1 w-full sm:w-auto">
          <Search className="w-4 h-4 text-slate-400 absolute inset-y-0 left-3 my-auto" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && fetchUsers()}
            placeholder="Search username, email, full name..."
            className="input-field pl-9"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="input-field text-xs py-2.5"
          >
            <option value="">All Account Roles</option>
            <option value="citizen">Citizens Only</option>
            <option value="staff">Staff / Inspectors Only</option>
            <option value="admin">Administrators Only</option>
          </select>
        </div>
      </div>

      {/* User Table */}
      {loading ? (
        <LoadingSpinner fullPage message="Fetching user directory..." />
      ) : (
        <div className="card-container overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-700 uppercase font-semibold text-[11px]">
                <tr>
                  <th className="px-4 py-3">User</th>
                  <th className="px-4 py-3">Role</th>
                  <th className="px-4 py-3">Assigned Department</th>
                  <th className="px-4 py-3">Contact</th>
                  <th className="px-4 py-3">Neighborhood</th>
                  <th className="px-4 py-3">Joined Date</th>
                  <th className="px-4 py-3 text-right">Edit</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {users.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-lg bg-slate-100 font-bold text-slate-700 text-xs flex items-center justify-center">
                          {u.first_name ? u.first_name[0] : u.username[0].toUpperCase()}
                        </div>
                        <div>
                          <span className="font-bold text-slate-900 block">
                            {u.first_name ? `${u.first_name} ${u.last_name || ''}` : u.username}
                          </span>
                          <span className="text-[11px] text-slate-400">@{u.username}</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3.5">
                      <span
                        className={`px-2.5 py-1 rounded-full text-xs font-semibold uppercase ${
                          u.role === 'admin'
                            ? 'bg-rose-100 text-rose-800'
                            : u.role === 'staff'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        {u.role}
                      </span>
                    </td>
                    <td className="px-4 py-3.5 text-slate-700">
                      {u.department_details?.name || (
                        <span className="text-slate-400 italic">None</span>
                      )}
                    </td>
                    <td className="px-4 py-3.5">
                      <div>{u.email}</div>
                      <div className="text-[11px] text-slate-400">{u.phone_number || '—'}</div>
                    </td>
                    <td className="px-4 py-3.5 truncate max-w-[120px]">{u.address || '—'}</td>
                    <td className="px-4 py-3.5 text-slate-400">
                      {new Date(u.date_joined).toLocaleDateString()}
                    </td>
                    <td className="px-4 py-3.5 text-right">
                      <button
                        onClick={() => handleEditClick(u)}
                        className="btn-secondary text-xs p-1.5"
                        title="Edit Roles"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Edit User Modal */}
      {editingUser && (
        <Modal
          isOpen={Boolean(editingUser)}
          onClose={() => setEditingUser(null)}
          title={`Edit Account: @${editingUser.username}`}
          subtitle={editingUser.email}
        >
          <form onSubmit={handleSaveUser} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Account Role *
              </label>
              <select
                value={selectedRole}
                onChange={(e) => setSelectedRole(e.target.value)}
                className="input-field"
                required
              >
                <option value="citizen">Citizen (Standard Resident)</option>
                <option value="staff">Staff / Inspector (Department Assigned)</option>
                <option value="admin">System Administrator (Full Control)</option>
              </select>
            </div>

            {selectedRole === 'staff' && (
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Designated Department *
                </label>
                <select
                  value={selectedDept}
                  onChange={(e) => setSelectedDept(e.target.value)}
                  className="input-field"
                  required
                >
                  <option value="">-- Choose Municipal Department --</option>
                  {departments.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name} ({d.code})
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div className="pt-2">
              <label className="flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isActive}
                  onChange={(e) => setIsActive(e.target.checked)}
                  className="rounded text-emerald-600 focus:ring-emerald-500"
                />
                Active Account (Allow login & platform access)
              </label>
            </div>

            <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setEditingUser(null)}
                disabled={saveLoading}
                className="btn-secondary"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={saveLoading}
                className="btn-primary"
              >
                {saveLoading ? 'Saving...' : 'Save Role Updates'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
};
