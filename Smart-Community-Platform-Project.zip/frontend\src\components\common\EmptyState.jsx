import React from 'react';
import { Inbox, Plus } from 'lucide-react';
import { Link } from 'react-router-dom';

export const EmptyState = ({
  icon: Icon = Inbox,
  title = 'No records found',
  description = 'There are no items to display at this moment.',
  actionText,
  actionLink,
  onAction,
}) => {
  return (
    <div className="flex flex-col items-center justify-center p-12 text-center bg-white rounded-xl border border-dashed border-slate-300">
      <div className="w-14 h-14 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 mb-4">
        <Icon className="w-7 h-7" />
      </div>
      <h3 className="text-base font-semibold text-slate-900 mb-1">{title}</h3>
      <p className="text-sm text-slate-500 max-w-sm mb-6">{description}</p>
      {actionLink ? (
        <Link to={actionLink} className="btn-primary">
          <Plus className="w-4 h-4 mr-1.5" />
          {actionText}
        </Link>
      ) : onAction && actionText ? (
        <button onClick={onAction} className="btn-primary">
          <Plus className="w-4 h-4 mr-1.5" />
          {actionText}
        </button>
      ) : null}
    </div>
  );
};
