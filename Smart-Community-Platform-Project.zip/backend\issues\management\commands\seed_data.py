from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from django.utils import timezone
from accounts.models import Department
from issues.models import IssueCategory, Issue, IssueComment, IssueActivityLog
from notifications.models import Notification

User = get_user_model()

class Command(BaseCommand):
    help = 'Seeds initial departments, categories, demo users, realistic civic issues, and notifications.'

    def handle(self, *args, **kwargs):
        self.stdout.write(self.style.NOTICE('Starting database seed...'))

        # 1. Departments
        departments_data = [
            {'name': 'Roads & Infrastructure', 'code': 'ROADS', 'email': 'roads@smartcommunity.gov', 'phone': '555-0101'},
            {'name': 'Sanitation & Waste Management', 'code': 'SANIT', 'email': 'sanitation@smartcommunity.gov', 'phone': '555-0102'},
            {'name': 'Electrical & Street Lighting', 'code': 'ELEC', 'email': 'power@smartcommunity.gov', 'phone': '555-0103'},
            {'name': 'Water & Sewage Authority', 'code': 'WATER', 'email': 'water@smartcommunity.gov', 'phone': '555-0104'},
            {'name': 'Stormwater Drainage & Flood Control', 'code': 'DRAIN', 'email': 'drainage@smartcommunity.gov', 'phone': '555-0105'},
            {'name': 'Parks & Public Recreation', 'code': 'PARKS', 'email': 'parks@smartcommunity.gov', 'phone': '555-0106'},
            {'name': 'Public Safety & Code Compliance', 'code': 'SAFETY', 'email': 'safety@smartcommunity.gov', 'phone': '555-0107'},
            {'name': 'General Municipal Services', 'code': 'GEN', 'email': 'help@smartcommunity.gov', 'phone': '555-0100'},
        ]

        dept_objs = {}
        for d in departments_data:
            dept, _ = Department.objects.get_or_create(
                code=d['code'],
                defaults={
                    'name': d['name'],
                    'contact_email': d['email'],
                    'contact_phone': d['phone'],
                    'description': f"Municipal service department for {d['name']}."
                }
            )
            dept_objs[d['code']] = dept

        self.stdout.write(self.style.SUCCESS(f'Created/verified {len(dept_objs)} departments.'))

        # 2. Categories
        categories_data = [
            {'name': 'Roads/Potholes', 'slug': 'roads-potholes', 'icon': 'Car', 'color': '#EF4444', 'dept': 'ROADS', 'desc': 'Potholes, damaged asphalt, road cracks, missing manholes, and curb issues.'},
            {'name': 'Streetlights', 'slug': 'streetlights', 'icon': 'Lightbulb', 'color': '#F59E0B', 'dept': 'ELEC', 'desc': 'Broken street lamps, flickering lights, dark streets, and exposed electrical wires.'},
            {'name': 'Garbage/Waste', 'slug': 'garbage-waste', 'icon': 'Trash2', 'color': '#10B981', 'dept': 'SANIT', 'desc': 'Overflowing bins, uncollected trash, illegal dumping, and hazardous debris.'},
            {'name': 'Water Supply', 'slug': 'water-supply', 'icon': 'Droplets', 'color': '#3B82F6', 'dept': 'WATER', 'desc': 'Water main leaks, low water pressure, contaminated water, or broken meters.'},
            {'name': 'Drainage', 'slug': 'drainage', 'icon': 'Waves', 'color': '#06B6D4', 'dept': 'DRAIN', 'desc': 'Clogged storm drains, stagnant water accumulation, sewer overflow, and flooding.'},
            {'name': 'Public Safety', 'slug': 'public-safety', 'icon': 'ShieldAlert', 'color': '#8B5CF6', 'dept': 'SAFETY', 'desc': 'Dangerous structures, missing warning signs, obstructed sightlines, and hazards.'},
            {'name': 'Parks/Public Spaces', 'slug': 'parks-public-spaces', 'icon': 'Trees', 'color': '#10B981', 'dept': 'PARKS', 'desc': 'Damaged playground equipment, broken park benches, overgrown vegetation, graffiti.'},
            {'name': 'Electricity', 'slug': 'electricity', 'icon': 'Zap', 'color': '#F59E0B', 'dept': 'ELEC', 'desc': 'Transformer faults, fallen power lines, sparking poles, or open utility boxes.'},
            {'name': 'Other', 'slug': 'other', 'icon': 'HelpCircle', 'color': '#6B7280', 'dept': 'GEN', 'desc': 'General civic complaints and unclassified community concerns.'},
        ]

        cat_objs = {}
        for cat in categories_data:
            c, _ = IssueCategory.objects.get_or_create(
                slug=cat['slug'],
                defaults={
                    'name': cat['name'],
                    'icon': cat['icon'],
                    'color': cat['color'],
                    'description': cat['desc'],
                    'default_department': dept_objs.get(cat['dept'])
                }
            )
            cat_objs[cat['slug']] = c

        self.stdout.write(self.style.SUCCESS(f'Created/verified {len(cat_objs)} categories.'))

        # 3. Users
        # Admin
        admin_user, _ = User.objects.get_or_create(
            username='admin',
            defaults={
                'email': 'admin@smartcommunity.gov',
                'first_name': 'Mayor',
                'last_name': 'Admin',
                'role': User.Role.ADMIN,
                'is_staff': True,
                'is_superuser': True,
                'phone_number': '+1-555-001-9999',
                'address': 'City Hall, 100 Civic Center Blvd',
            }
        )
        admin_user.set_password('Admin@123')
        admin_user.role = User.Role.ADMIN
        admin_user.is_staff = True
        admin_user.is_superuser = True
        admin_user.save()

        # Staff
        staff_user, _ = User.objects.get_or_create(
            username='john_staff',
            defaults={
                'email': 'john.field@smartcommunity.gov',
                'first_name': 'John',
                'last_name': 'Inspector',
                'role': User.Role.STAFF,
                'is_staff': True,
                'department': dept_objs.get('ROADS'),
                'phone_number': '+1-555-002-4422',
                'address': 'Public Works Depot #3',
            }
        )
        staff_user.set_password('Staff@123')
        staff_user.role = User.Role.STAFF
        staff_user.department = dept_objs.get('ROADS')
        staff_user.is_staff = True
        staff_user.save()

        # Citizen Jane
        citizen_jane, _ = User.objects.get_or_create(
            username='citizen_jane',
            defaults={
                'email': 'jane.citizen@example.com',
                'first_name': 'Jane',
                'last_name': 'Doe',
                'role': User.Role.CITIZEN,
                'phone_number': '+1-555-123-4567',
                'address': '442 Elmwood Ave, Apartment 3B',
            }
        )
        citizen_jane.set_password('Citizen@123')
        citizen_jane.save()

        # Citizen Mark
        citizen_mark, _ = User.objects.get_or_create(
            username='citizen_mark',
            defaults={
                'email': 'mark.resident@example.com',
                'first_name': 'Mark',
                'last_name': 'Stevens',
                'role': User.Role.CITIZEN,
                'phone_number': '+1-555-987-6543',
                'address': '18 Greenfield Rd',
            }
        )
        citizen_mark.set_password('Citizen@123')
        citizen_mark.save()

        self.stdout.write(self.style.SUCCESS('Created demo user accounts (admin, john_staff, citizen_jane, citizen_mark).'))

        # 4. Realistic Sample Issues
        sample_issues = [
            {
                'title': 'Dangerous Deep Pothole on Oak & 5th Avenue Intersection',
                'description': 'A massive 8-inch deep pothole has opened up right in the westbound turning lane. Multiple vehicles have suffered tire blowouts in the past 24 hours.',
                'category': 'roads-potholes',
                'status': Issue.Status.IN_PROGRESS,
                'priority': Issue.Priority.URGENT,
                'location': 'Corner of 5th Ave and Oak Street',
                'lat': 40.7128,
                'lng': -74.0060,
                'citizen': citizen_jane,
                'dept': 'ROADS',
                'assigned_to': staff_user,
            },
            {
                'title': 'Four Consecutive Streetlights Flickering and Blacked Out',
                'description': 'Streetlights #104 through #108 along Maple Parkway have been completely out for 4 nights, causing poor visibility for pedestrians and evening commuters.',
                'category': 'streetlights',
                'status': Issue.Status.ASSIGNED,
                'priority': Issue.Priority.HIGH,
                'location': 'Maple Parkway between 12th & 14th St',
                'lat': 40.7180,
                'lng': -74.0100,
                'citizen': citizen_mark,
                'dept': 'ELEC',
                'assigned_to': None,
            },
            {
                'title': 'Severe Overflowing Dumpsters at Riverside Community Park',
                'description': 'Weekend festival left excess trash overflowing into adjacent walkways and lawn. Attracting stray animals and creating strong odors.',
                'category': 'garbage-waste',
                'status': Issue.Status.RESOLVED,
                'priority': Issue.Priority.MEDIUM,
                'location': 'Riverside Park, North Pavilion',
                'lat': 40.7205,
                'lng': -74.0150,
                'citizen': citizen_jane,
                'dept': 'SANIT',
                'assigned_to': None,
                'resolved': True,
                'res_notes': 'Sanitation crew dispatched on Tuesday 09:00 AM. Area cleared and 2 extra dumpsters deployed.'
            },
            {
                'title': 'Freshwater Main Pipe Leaking and Flooding Sidewalk',
                'description': 'Clean water has been gushing from beneath the pedestrian sidewalk near the library for over 12 hours. Significant water wastage.',
                'category': 'water-supply',
                'status': Issue.Status.UNDER_REVIEW,
                'priority': Issue.Priority.HIGH,
                'location': '742 Civic Square (In front of City Library)',
                'lat': 40.7150,
                'lng': -74.0020,
                'citizen': citizen_mark,
                'dept': 'WATER',
                'assigned_to': None,
            },
            {
                'title': 'Storm Drainage Grate Completely Clogged with Leaves & Silt',
                'description': 'The low-point drainage basin at the corner is completely blocked. Even moderate rain causes 6 inches of ponding on the pedestrian crosswalk.',
                'category': 'drainage',
                'status': Issue.Status.REPORTED,
                'priority': Issue.Priority.MEDIUM,
                'location': 'Intersection of Pine & Blossom Lane',
                'lat': 40.7110,
                'lng': -73.9980,
                'citizen': citizen_jane,
                'dept': 'DRAIN',
                'assigned_to': None,
            },
            {
                'title': 'Fallen Tree Limb Obstructing Playground Pathway',
                'description': 'A large oak tree limb snapped during yesterday storm and is blocking the walking path near the toddlers play area.',
                'category': 'parks-public-spaces',
                'status': Issue.Status.IN_PROGRESS,
                'priority': Issue.Priority.MEDIUM,
                'location': 'Central Community Gardens, West Gate',
                'lat': 40.7240,
                'lng': -74.0080,
                'citizen': citizen_mark,
                'dept': 'PARKS',
                'assigned_to': None,
            }
        ]

        for item in sample_issues:
            issue, created = Issue.objects.get_or_create(
                title=item['title'],
                defaults={
                    'description': item['description'],
                    'category': cat_objs[item['category']],
                    'status': item['status'],
                    'priority': item['priority'],
                    'location': item['location'],
                    'latitude': item['lat'],
                    'longitude': item['lng'],
                    'citizen': item['citizen'],
                    'assigned_department': dept_objs.get(item['dept']),
                    'assigned_to': item.get('assigned_to'),
                    'resolution_notes': item.get('res_notes', ''),
                    'resolved_at': timezone.now() if item.get('resolved') else None,
                }
            )

            if created:
                # Log creation
                IssueActivityLog.objects.create(
                    issue=issue,
                    performed_by=item['citizen'],
                    action='Issue reported by resident',
                    new_status=Issue.Status.REPORTED,
                    notes='Citizen submitted initial problem report.'
                )

                # Add sample comment
                IssueComment.objects.create(
                    issue=issue,
                    author=admin_user,
                    text="Our municipal triage team has reviewed this ticket and notified field inspectors.",
                    is_internal=False
                )

                # Add notification
                Notification.objects.create(
                    recipient=item['citizen'],
                    issue=issue,
                    title=f"Report #{issue.id} Status: {issue.get_status_display()}",
                    message=f"Your ticket '{issue.title[:30]}...' is now in {issue.get_status_display()} status.",
                    notification_type=Notification.NotificationType.STATUS_CHANGE
                )

        self.stdout.write(self.style.SUCCESS(f'Successfully populated database with demo civic issues!'))
        self.stdout.write(self.style.SUCCESS('Ready to run: python manage.py runserver'))
