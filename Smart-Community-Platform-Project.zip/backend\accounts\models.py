from django.db import models
from django.contrib.auth.models import AbstractUser

class Department(models.Model):
    """
    Municipal / Civic department responsible for resolving assigned community issues.
    """
    name = models.CharField(max_length=120, unique=True)
    code = models.CharField(max_length=20, unique=True, help_text="e.g. ROADS, ELEC, SANIT, WATER")
    description = models.TextField(blank=True, default='')
    contact_email = models.EmailField(blank=True, default='')
    contact_phone = models.CharField(max_length=20, blank=True, default='')
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['name']
        verbose_name = 'Department'
        verbose_name_plural = 'Departments'

    def __str__(self):
        return f"{self.name} ({self.code})"


class User(AbstractUser):
    """
    Custom user model supporting Citizens, Department Staff/Authorities, and Administrators.
    """
    class Role(models.TextChoices):
        CITIZEN = 'citizen', 'Citizen / Resident'
        STAFF = 'staff', 'Department Authority / Staff'
        ADMIN = 'admin', 'System Administrator'

    email = models.EmailField(unique=True, verbose_name='Email Address')
    role = models.CharField(
        max_length=20,
        choices=Role.choices,
        default=Role.CITIZEN,
        help_text="Role determines access level and available dashboard tools."
    )
    phone_number = models.CharField(max_length=20, blank=True, default='')
    address = models.TextField(blank=True, default='', help_text="Neighborhood / Community street address")
    avatar = models.ImageField(upload_to='avatars/', null=True, blank=True)
    department = models.ForeignKey(
        Department,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='staff_members',
        help_text="Assigned municipal department for staff/authority users."
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['email']

    class Meta:
        ordering = ['-date_joined']
        verbose_name = 'User'
        verbose_name_plural = 'Users'

    def __str__(self):
        full_name = self.get_full_name()
        return f"{full_name or self.username} [{self.get_role_display()}]"

    @property
    def is_citizen(self):
        return self.role == self.Role.CITIZEN

    @property
    def is_authority(self):
        return self.role in [self.Role.STAFF, self.Role.ADMIN] or self.is_staff or self.is_superuser

    @property
    def is_platform_admin(self):
        return self.role == self.Role.ADMIN or self.is_superuser
