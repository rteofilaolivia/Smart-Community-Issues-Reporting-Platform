from django.db import models
from django.conf import settings
from issues.models import Issue

class Notification(models.Model):
    """
    In-app alert notification sent to citizens and staff when issue status changes or updates occur.
    """
    class NotificationType(models.TextChoices):
        STATUS_CHANGE = 'status_change', 'Status Update'
        ASSIGNMENT = 'assignment', 'Assignment'
        COMMENT = 'comment', 'New Comment'
        SYSTEM = 'system', 'System Notice'

    recipient = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='notifications'
    )
    issue = models.ForeignKey(
        Issue,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='notifications'
    )
    title = models.CharField(max_length=255)
    message = models.TextField()
    notification_type = models.CharField(
        max_length=30,
        choices=NotificationType.choices,
        default=NotificationType.STATUS_CHANGE
    )
    is_read = models.BooleanField(default=False, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Notification'
        verbose_name_plural = 'Notifications'

    def __str__(self):
        return f"Notification for {self.recipient.username}: {self.title}"
