@echo off
title Smart Community Platform Launcher
color 0A

echo ========================================================
echo   Starting Smart Community Issues Reporting Platform...
echo ========================================================
echo.

set PATH=C:\Program Files\nodejs;C:\Python312;C:\Python312\Scripts;%PATH%
set ROOT_DIR=%~dp0

echo [1/2] Starting Django REST Backend Server (Port 8000)...
start "Smart Community - Backend" cmd /k "cd /d %ROOT_DIR%backend && .\venv\Scripts\python.exe manage.py runserver 0.0.0.0:8000"

echo [2/2] Starting React Frontend Server (Port 5173)...
start "Smart Community - Frontend" cmd /k "cd /d %ROOT_DIR%frontend && npm run dev"

echo.
echo Waiting for servers to initialize...
timeout /t 4 /nobreak >nul

for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /i "IPv4" ^| findstr /v "169.254"') do (
    set LOCAL_IP=%%a
    goto :found_ip
)
:found_ip
set LOCAL_IP=%LOCAL_IP: =%

echo Opening platform in your web browser...
start http://localhost:5173

echo.
echo ========================================================
echo   Platform is running! Keep the backend/frontend windows open.
echo.
echo   [1] Open on THIS laptop:
echo       http://localhost:5173
echo.
echo   [2] Open on OTHER laptops (same Wi-Fi):
echo       http://%LOCAL_IP%:5173
echo ========================================================
echo.
pause
