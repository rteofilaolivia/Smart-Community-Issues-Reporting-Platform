from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, Department

@admin.register(User)
class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'first_name', 'last_name', 'role', 'department', 'is_staff', 'is_active')
    list_filter = ('role', 'is_staff', 'is_superuser', 'is_active', 'department')
    fieldsets = UserAdmin.fieldsets + (
        ('Smart Community Profile', {
            'fields': ('role', 'phone_number', 'address', 'avatar', 'department')
        }),
    )
    add_fieldsets = UserAdmin.add_fieldsets + (
        ('Smart Community Profile', {
            'fields': ('email', 'role', 'phone_number', 'address', 'department')
        }),
    )
    search_fields = ('username', 'email', 'first_name', 'last_name', 'phone_number')


@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ('name', 'code', 'contact_email', 'contact_phone', 'is_active', 'created_at')
    list_filter = ('is_active',)
    search_fields = ('name', 'code', 'description')
