import React from 'react';
import { MapPin, Navigation, Crosshair } from 'lucide-react';

export const LocationPicker = ({ location, latitude, longitude, onChange }) => {
  // Predefined community hubs/landmarks for quick filling
  const presetLocations = [
    { name: 'City Hall & Civic Center', lat: 40.7128, lng: -74.0060 },
    { name: 'Central Community Park (North Gate)', lat: 40.7205, lng: -74.0150 },
    { name: 'Public Library & Education Center', lat: 40.7150, lng: -74.0020 },
    { name: 'Metro Transit Hub (Main Station)', lat: 40.7180, lng: -74.0100 },
  ];

  const handleGetCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          onChange({
            location: location || `GPS: ${position.coords.latitude.toFixed(4)}, ${position.coords.longitude.toFixed(4)}`,
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          });
        },
        (error) => {
          console.warn('Geolocation error:', error);
          alert('Could not access current location. Please type the address manually.');
        }
      );
    }
  };

  const handlePresetSelect = (preset) => {
    onChange({
      location: preset.name,
      latitude: preset.lat,
      longitude: preset.lng,
    });
  };

  return (
    <div className="space-y-3">
      <div>
        <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
          Issue Location / Street Address *
        </label>
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
            <MapPin className="w-4 h-4 text-emerald-600" />
          </div>
          <input
            type="text"
            required
            value={location}
            onChange={(e) => onChange({ location: e.target.value, latitude, longitude })}
            placeholder="e.g. 142 Elmwood Street or Corner of 5th Ave"
            className="input-field pl-9 pr-24"
          />
          <button
            type="button"
            onClick={handleGetCurrentLocation}
            className="absolute inset-y-1.5 right-1.5 px-2.5 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-md transition-colors flex items-center gap-1"
          >
            <Navigation className="w-3 h-3" />
            GPS Locate
          </button>
        </div>
      </div>

      {/* Lat / Long Coordinate inputs */}
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block text-[11px] font-medium text-slate-500 mb-1">
            Latitude (Optional)
          </label>
          <input
            type="number"
            step="any"
            value={latitude || ''}
            onChange={(e) =>
              onChange({
                location,
                latitude: e.target.value ? parseFloat(e.target.value) : null,
                longitude,
              })
            }
            placeholder="40.7128"
            className="input-field text-xs py-2"
          />
        </div>
        <div>
          <label className="block text-[11px] font-medium text-slate-500 mb-1">
            Longitude (Optional)
          </label>
          <input
            type="number"
            step="any"
            value={longitude || ''}
            onChange={(e) =>
              onChange({
                location,
                latitude,
                longitude: e.target.value ? parseFloat(e.target.value) : null,
              })
            }
            placeholder="-74.0060"
            className="input-field text-xs py-2"
          />
        </div>
      </div>

      {/* Quick Landmark Presets */}
      <div>
        <span className="text-[11px] text-slate-400 font-medium block mb-1.5">
          Quick Landmark Select:
        </span>
        <div className="flex flex-wrap gap-1.5">
          {presetLocations.map((preset) => (
            <button
              key={preset.name}
              type="button"
              onClick={() => handlePresetSelect(preset)}
              className="text-[11px] px-2.5 py-1 rounded-md bg-slate-100 text-slate-600 hover:bg-emerald-50 hover:text-emerald-700 transition-colors border border-slate-200/60"
            >
              {preset.name}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
