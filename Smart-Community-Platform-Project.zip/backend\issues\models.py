from django.db import models
from django.conf import settings
from accounts.models import Department

class IssueCategory(models.Model):
    """
    Standard civic categories for community issues.
    """
    name = models.CharField(max_length=100, unique=True)
    slug = models.SlugField(max_length=100, unique=True)
    description = models.TextField(blank=True, default='')
    icon = models.CharField(max_length=50, default='AlertCircle', help_text="Lucide icon name identifier")
    color = models.CharField(max_length=20, default='#3B82F6', help_text="Hex color code for badge styling")
    is_active = models.BooleanField(default=True)
    default_department = models.ForeignKey(
        Department,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='categories'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['name']
        verbose_name = 'Issue Category'
        verbose_name_plural = 'Issue Categories'

    def __str__(self):
        return self.name


class Issue(models.Model):
    """
    Core Civic Issue reported by a citizen.
    """
    class Status(models.TextChoices):
        REPORTED = 'reported', 'Reported'
        UNDER_REVIEW = 'under_review', 'Under Review'
        ASSIGNED = 'assigned', 'Assigned'
        IN_PROGRESS = 'in_progress', 'In Progress'
        RESOLVED = 'resolved', 'Resolved'
        REJECTED = 'rejected', 'Rejected'

    class Priority(models.TextChoices):
        LOW = 'low', 'Low'
        MEDIUM = 'medium', 'Medium'
        HIGH = 'high', 'High'
        URGENT = 'urgent', 'Urgent'

    title = models.CharField(max_length=200, help_text="Clear, concise summary of the issue")
    description = models.TextField(help_text="Detailed description of the civic problem")
    category = models.ForeignKey(
        IssueCategory,
        on_delete=models.PROTECT,
        related_name='issues'
    )
    status = models.CharField(
        max_length=20,
        choices=Status.choices,
        default=Status.REPORTED,
        db_index=True
    )
    priority = models.CharField(
        max_length=20,
        choices=Priority.choices,
        default=Priority.MEDIUM,
        db_index=True
    )
    location = models.CharField(
        max_length=255,
        help_text="Human-readable street address or landmark"
    )
    latitude = models.FloatField(
        null=True,
        blank=True,
        help_text="GPS Latitude coordinate"
    )
    longitude = models.FloatField(
        null=True,
        blank=True,
        help_text="GPS Longitude coordinate"
    )
    image = models.ImageField(
        upload_to='issues/%Y/%m/',
        null=True,
        blank=True,
        help_text="Photo evidence of the reported problem"
    )
    citizen = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='reported_issues'
    )
    assigned_department = models.ForeignKey(
        Department,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='assigned_issues'
    )
    assigned_to = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='assigned_tasks'
    )
    rejection_reason = models.TextField(blank=True, default='')
    resolution_notes = models.TextField(blank=True, default='')
    resolved_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Civic Issue'
        verbose_name_plural = 'Civic Issues'

    def __str__(self):
        return f"[{self.get_status_display()}] {self.title} ({self.category.name})"


class IssueComment(models.Model):
    """
    Public community comments or internal authority discussion notes on an issue.
    """
    issue = models.ForeignKey(
        Issue,
        on_delete=models.CASCADE,
        related_name='comments'
    )
    author = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='issue_comments'
    )
    text = models.TextField()
    is_internal = models.BooleanField(
        default=False,
        help_text="Internal notes are visible only to Staff and Administrators."
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['created_at']
        verbose_name = 'Issue Comment'
        verbose_name_plural = 'Issue Comments'

    def __str__(self):
        return f"Comment by {self.author.username} on Issue #{self.issue.id}"


class IssueActivityLog(models.Model):
    """
    Complete immutable audit timeline of status changes, assignments, and resolution notes.
    """
    issue = models.ForeignKey(
        Issue,
        on_delete=models.CASCADE,
        related_name='activities'
    )
    performed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )
    action = models.CharField(max_length=255)
    old_status = models.CharField(max_length=30, blank=True, default='')
    new_status = models.CharField(max_length=30, blank=True, default='')
    notes = models.TextField(blank=True, default='')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['created_at']
        verbose_name = 'Issue Activity Log'
        verbose_name_plural = 'Issue Activity Logs'

    def __str__(self):
        return f"Activity on Issue #{self.issue_id}: {self.action}"
