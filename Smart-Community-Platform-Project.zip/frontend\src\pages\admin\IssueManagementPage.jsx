import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Search, 
  Filter, 
  RefreshCw, 
  Building2, 
  UserCheck, 
  Trash2, 
  Edit3, 
  ExternalLink,
  Plus
} from 'lucide-react';
import { issueService } from '../../services/issueService';
import { authService } from '../../services/authService';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { StatusBadge } from '../../components/common/StatusBadge';
import { PriorityBadge } from '../../components/common/PriorityBadge';
import { LoadingSpinner } from '../../components/common/LoadingSpinner';
import { EmptyState } from '../../components/common/EmptyState';
import { StatusUpdateModal } from '../../components/issues/StatusUpdateModal';
import { AssignModal } from '../../components/issues/AssignModal';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';

export const IssueManagementPage = () => {
  const { isAdmin } = useAuth();
  const { success, error } = useToast();

  const [issues, setIssues] = useState([]);
  const [categories, setCategories] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filter States
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [selectedPriority, setSelectedPriority] = useState('');
  const [selectedDept, setSelectedDept] = useState('');

  // Modals
  const [activeIssue, setActiveIssue] = useState(null);
  const [isStatusOpen, setIsStatusOpen] = useState(false);
  const [isAssignOpen, setIsAssignOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);

  const fetchIssues = async () => {
    setLoading(true);
    try {
      const params = {};
      if (search) params.search = search;
      if (selectedCategory) params.category = selectedCategory;
      if (selectedStatus) params.status = selectedStatus;
      if (selectedPriority) params.priority = selectedPriority;
      if (selectedDept) params.department = selectedDept;

      const data = await issueService.getIssues(params);
      setIssues(data.results || data);
    } catch (err) {
      console.error('Failed to load issues for management:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const loadInitialOptions = async () => {
      try {
        const [cats, depts] = await Promise.all([
          issueService.getCategories(),
          authService.getDepartments(),
        ]);
        setCategories(cats);
        setDepartments(depts);
      } catch (err) {
        console.error('Failed to load filter options:', err);
      }
    };
    loadInitialOptions();
  }, []);

  useEffect(() => {
    fetchIssues();
  }, [selectedCategory, selectedStatus, selectedPriority, selectedDept]);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    fetchIssues();
  };

  const handleDeleteConfirm = async () => {
    if (!activeIssue) return;
    setDeleteLoading(true);
    try {
      await issueService.deleteIssue(activeIssue.id);
      success(`Ticket #${activeIssue.id} deleted successfully.`);
      setIsDeleteOpen(false);
      setActiveIssue(null);
      fetchIssues();
    } catch (err) {
      console.error('Failed to delete issue:', err);
      error('Failed to delete issue ticket.');
    } finally {
      setDeleteLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            Issue Management & Triage
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Dispatch, assign, and resolve community infrastructure reports ({issues.length} active)
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={fetchIssues}
            className="btn-secondary text-xs"
            title="Refresh List"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} /> Refresh
          </button>
          <Link to="/report" className="btn-primary text-xs">
            <Plus className="w-4 h-4 mr-1" /> New Report
          </Link>
        </div>
      </div>

      {/* Multi-Filter Bar */}
      <div className="card-container p-4 space-y-3">
        <form onSubmit={handleSearchSubmit} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute inset-y-0 left-3 my-auto" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search title, citizen name, address..."
              className="input-field pl-9"
            />
          </div>
          <button type="submit" className="btn-primary text-xs">
            Search
          </button>
        </form>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-2 border-t border-slate-100">
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
              Category
            </label>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="input-field text-xs py-2"
            >
              <option value="">All Categories</option>
              {categories.map((c) => (
                <option key={c.slug} value={c.slug}>{c.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
              Status
            </label>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="input-field text-xs py-2"
            >
              <option value="">All Statuses</option>
              <option value="reported">Reported</option>
              <option value="under_review">Under Review</option>
              <option value="assigned">Assigned</option>
              <option value="in_progress">In Progress</option>
              <option value="resolved">Resolved</option>
              <option value="rejected">Rejected</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
              Priority
            </label>
            <select
              value={selectedPriority}
              onChange={(e) => setSelectedPriority(e.target.value)}
              className="input-field text-xs py-2"
            >
              <option value="">All Priorities</option>
              <option value="urgent">Urgent</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
              Department
            </label>
            <select
              value={selectedDept}
              onChange={(e) => setSelectedDept(e.target.value)}
              className="input-field text-xs py-2"
            >
              <option value="">All Departments</option>
              {departments.map((d) => (
                <option key={d.id} value={d.id}>{d.name}</option>
              ))}
            </select>
          </div>

          <div className="flex items-end">
            <button
              type="button"
              onClick={() => {
                setSearch('');
                setSelectedCategory('');
                setSelectedStatus('');
                setSelectedPriority('');
                setSelectedDept('');
              }}
              className="btn-secondary w-full text-xs py-2"
            >
              Reset
            </button>
          </div>
        </div>
      </div>

      {/* Table */}
      {loading ? (
        <LoadingSpinner fullPage message="Filtering municipal tickets..." />
      ) : issues.length === 0 ? (
        <EmptyState
          title="No issues match the selected criteria"
          description="Try modifying or clearing your filters to see more results."
        />
      ) : (
        <div className="card-container overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-700 uppercase font-semibold text-[11px]">
                <tr>
                  <th className="px-4 py-3">ID</th>
                  <th className="px-4 py-3">Issue Title</th>
                  <th className="px-4 py-3">Category</th>
                  <th className="px-4 py-3">Priority</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Location</th>
                  <th className="px-4 py-3">Assigned Dept</th>
                  <th className="px-4 py-3">Citizen</th>
                  <th className="px-4 py-3">Reported</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {issues.map((issue) => (
                  <tr key={issue.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-4 py-3.5 font-bold text-slate-900">#{issue.id}</td>
                    <td className="px-4 py-3.5 font-semibold text-slate-900 max-w-xs truncate">
                      <Link to={`/issues/${issue.id}`} className="hover:text-emerald-700">
                        {issue.title}
                      </Link>
                    </td>
                    <td className="px-4 py-3.5">
                      <span
                        className="px-2 py-0.5 rounded text-[11px] font-medium"
                        style={{
                          backgroundColor: `${issue.category_color || '#3b82f6'}15`,
                          color: issue.category_color || '#2563eb',
                        }}
                      >
                        {issue.category_name}
                      </span>
                    </td>
                    <td className="px-4 py-3.5">
                      <PriorityBadge priority={issue.priority} />
                    </td>
                    <td className="px-4 py-3.5">
                      <StatusBadge status={issue.status} />
                    </td>
                    <td className="px-4 py-3.5 truncate max-w-[120px]">{issue.location}</td>
                    <td className="px-4 py-3.5 text-slate-700">
                      {issue.assigned_department_name || (
                        <span className="text-slate-400 italic">Unassigned</span>
                      )}
                    </td>
                    <td className="px-4 py-3.5 truncate max-w-[100px]">{issue.citizen_name}</td>
                    <td className="px-4 py-3.5 text-slate-400">
                      {new Date(issue.created_at).toLocaleDateString()}
                    </td>
                    <td className="px-4 py-3.5 text-right whitespace-nowrap space-x-1.5">
                      <button
                        onClick={() => {
                          setActiveIssue(issue);
                          setIsStatusOpen(true);
                        }}
                        className="p-1.5 rounded-lg text-emerald-700 hover:bg-emerald-50"
                        title="Update Status"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          setActiveIssue(issue);
                          setIsAssignOpen(true);
                        }}
                        className="p-1.5 rounded-lg text-blue-700 hover:bg-blue-50"
                        title="Assign Department"
                      >
                        <Building2 className="w-3.5 h-3.5" />
                      </button>
                      <Link
                        to={`/issues/${issue.id}`}
                        className="p-1.5 rounded-lg text-slate-600 hover:bg-slate-100 inline-block"
                        title="View Details"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                      </Link>
                      {isAdmin && (
                        <button
                          onClick={() => {
                            setActiveIssue(issue);
                            setIsDeleteOpen(true);
                          }}
                          className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-50"
                          title="Delete Issue"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modals */}
      {activeIssue && (
        <>
          <StatusUpdateModal
            isOpen={isStatusOpen}
            onClose={() => {
              setIsStatusOpen(false);
              setActiveIssue(null);
            }}
            issue={activeIssue}
            onStatusUpdated={() => fetchIssues()}
          />

          <AssignModal
            isOpen={isAssignOpen}
            onClose={() => {
              setIsAssignOpen(false);
              setActiveIssue(null);
            }}
            issue={activeIssue}
            onAssigned={() => fetchIssues()}
          />

          <ConfirmDialog
            isOpen={isDeleteOpen}
            onClose={() => {
              setIsDeleteOpen(false);
              setActiveIssue(null);
            }}
            onConfirm={handleDeleteConfirm}
            title={`Delete Ticket #${activeIssue.id}?`}
            message={`Are you sure you want to delete "${activeIssue.title}"? This cannot be undone.`}
            isLoading={deleteLoading}
          />
        </>
      )}
    </div>
  );
};
