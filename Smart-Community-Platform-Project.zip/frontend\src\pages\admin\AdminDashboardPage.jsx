import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  ShieldCheck, 
  AlertCircle, 
  CheckCircle2, 
  Clock, 
  PlayCircle, 
  XCircle, 
  Users, 
  TrendingUp, 
  ArrowRight,
  RefreshCw,
  Building2,
  FileText
} from 'lucide-react';
import { analyticsService } from '../../services/analyticsService';
import { issueService } from '../../services/issueService';
import { StatCard } from '../../components/dashboard/StatCard';
import { SimpleBarChart } from '../../components/dashboard/SimpleBarChart';
import { SimpleDonutChart } from '../../components/dashboard/SimpleDonutChart';
import { StatusBadge } from '../../components/common/StatusBadge';
import { PriorityBadge } from '../../components/common/PriorityBadge';
import { LoadingSpinner } from '../../components/common/LoadingSpinner';
import { StatusUpdateModal } from '../../components/issues/StatusUpdateModal';
import { AssignModal } from '../../components/issues/AssignModal';

export const AdminDashboardPage = () => {
  const [overview, setOverview] = useState({});
  const [categoryData, setCategoryData] = useState([]);
  const [statusData, setStatusData] = useState([]);
  const [urgentIssues, setUrgentIssues] = useState([]);
  const [recentActivities, setRecentActivities] = useState([]);
  const [loading, setLoading] = useState(true);

  // Modals
  const [selectedIssue, setSelectedIssue] = useState(null);
  const [isStatusModalOpen, setIsStatusModalOpen] = useState(false);
  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const [ov, cats, statuses, issues, activities] = await Promise.all([
        analyticsService.getOverview(),
        analyticsService.getCategoryBreakdown(),
        analyticsService.getStatusBreakdown(),
        issueService.getIssues({ ordering: '-priority,-created_at' }),
        analyticsService.getActivityFeed(),
      ]);

      setOverview(ov);
      setCategoryData(cats);
      setStatusData(statuses);
      setUrgentIssues((issues.results || issues).slice(0, 5));
      setRecentActivities(activities || []);
    } catch (err) {
      console.error('Failed to load admin dashboard:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const handleOpenStatus = (issue) => {
    setSelectedIssue(issue);
    setIsStatusModalOpen(true);
  };

  const handleOpenAssign = (issue) => {
    setSelectedIssue(issue);
    setIsAssignModalOpen(true);
  };

  if (loading) {
    return <LoadingSpinner fullPage message="Loading municipal intelligence dashboard..." />;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <ShieldCheck className="w-5 h-5 text-emerald-600" />
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-700">
              Authority Operations Center
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            Municipal Command Dashboard
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={fetchDashboardData}
            className="btn-secondary text-xs"
            title="Refresh Metrics"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} /> Refresh
          </button>

          <Link to="/admin/issues" className="btn-primary text-xs">
            <FileText className="w-4 h-4 mr-1.5" /> Full Issue Triage
          </Link>
        </div>
      </div>

      {/* KPI Stat Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        <StatCard
          title="Total Reports"
          value={overview.total_issues}
          icon={FileText}
          color="slate"
        />
        <StatCard
          title="New / Reported"
          value={overview.reported_issues}
          icon={AlertCircle}
          color="blue"
        />
        <StatCard
          title="Under Review"
          value={overview.under_review_issues}
          icon={Clock}
          color="amber"
        />
        <StatCard
          title="In Progress"
          value={overview.in_progress_issues}
          icon={PlayCircle}
          color="purple"
        />
        <StatCard
          title="Resolved"
          value={overview.resolved_issues}
          icon={CheckCircle2}
          color="emerald"
        />
        <StatCard
          title="Registered Users"
          value={overview.total_users || 0}
          icon={Users}
          color="slate"
        />
      </div>

      {/* Visual Analytics Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <SimpleBarChart
          data={categoryData}
          title="Civic Issues Breakdown by Category"
        />
        <SimpleDonutChart
          data={statusData}
          title="Issue Resolution Workflow Status"
        />
      </div>

      {/* Urgent Issues Triage Queue */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-base text-slate-900">Priority Triage Queue</h3>
            <p className="text-xs text-slate-500">Urgent community reports requiring immediate action</p>
          </div>
          <Link
            to="/admin/issues"
            className="text-xs font-semibold text-emerald-600 hover:text-emerald-700 flex items-center gap-1"
          >
            Manage All Issues <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="card-container overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-700 uppercase font-semibold text-[11px]">
                <tr>
                  <th className="px-4 py-3">ID</th>
                  <th className="px-4 py-3">Issue Title</th>
                  <th className="px-4 py-3">Category</th>
                  <th className="px-4 py-3">Priority</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Assigned Dept</th>
                  <th className="px-4 py-3 text-right">Quick Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {urgentIssues.map((issue) => (
                  <tr key={issue.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-4 py-3.5 font-bold text-slate-900">#{issue.id}</td>
                    <td className="px-4 py-3.5 font-semibold text-slate-900 max-w-xs truncate">
                      <Link to={`/issues/${issue.id}`} className="hover:text-emerald-600">
                        {issue.title}
                      </Link>
                    </td>
                    <td className="px-4 py-3.5">{issue.category_name}</td>
                    <td className="px-4 py-3.5">
                      <PriorityBadge priority={issue.priority} />
                    </td>
                    <td className="px-4 py-3.5">
                      <StatusBadge status={issue.status} />
                    </td>
                    <td className="px-4 py-3.5 text-slate-700">
                      {issue.assigned_department_name || (
                        <span className="text-slate-400 italic">Unassigned</span>
                      )}
                    </td>
                    <td className="px-4 py-3.5 text-right space-x-2">
                      <button
                        onClick={() => handleOpenStatus(issue)}
                        className="text-[11px] font-semibold text-emerald-600 hover:text-emerald-700 hover:underline"
                      >
                        Status
                      </button>
                      <button
                        onClick={() => handleOpenAssign(issue)}
                        className="text-[11px] font-semibold text-blue-600 hover:text-blue-700 hover:underline"
                      >
                        Assign
                      </button>
                      <Link
                        to={`/issues/${issue.id}`}
                        className="text-[11px] font-semibold text-slate-600 hover:text-slate-900 hover:underline"
                      >
                        Details
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Modals */}
      {selectedIssue && (
        <>
          <StatusUpdateModal
            isOpen={isStatusModalOpen}
            onClose={() => {
              setIsStatusModalOpen(false);
              setSelectedIssue(null);
            }}
            issue={selectedIssue}
            onStatusUpdated={() => fetchDashboardData()}
          />
          <AssignModal
            isOpen={isAssignModalOpen}
            onClose={() => {
              setIsAssignModalOpen(false);
              setSelectedIssue(null);
            }}
            issue={selectedIssue}
            onAssigned={() => fetchDashboardData()}
          />
        </>
      )}
    </div>
  );
};
