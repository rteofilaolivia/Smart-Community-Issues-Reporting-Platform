import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  FilePlus, 
  FileText, 
  User, 
  ShieldCheck, 
  Users, 
  BarChart3, 
  Compass,
  AlertCircle
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const Sidebar = ({ type = 'user' }) => {
  const { user, isAdmin, isAuthority } = useAuth();

  const userNav = [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { name: 'Report Issue', path: '/report', icon: FilePlus },
    { name: 'My Reports', path: '/my-reports', icon: FileText },
    { name: 'Public Feed', path: '/feed', icon: Compass },
    { name: 'My Profile', path: '/profile', icon: User },
  ];

  const adminNav = [
    { name: 'Admin Dashboard', path: '/admin/dashboard', icon: LayoutDashboard },
    { name: 'All Issues Triage', path: '/admin/issues', icon: AlertCircle },
    { name: 'Analytics & Reports', path: '/admin/analytics', icon: BarChart3 },
    ...(isAdmin ? [{ name: 'User Management', path: '/admin/users', icon: Users }] : []),
    { name: 'Public Feed', path: '/feed', icon: Compass },
    { name: 'My Profile', path: '/profile', icon: User },
  ];

  const links = type === 'admin' || isAuthority ? adminNav : userNav;

  return (
    <aside className="w-64 bg-white border-r border-slate-200 min-h-[calc(100vh-4rem)] p-4 flex flex-col justify-between hidden md:flex">
      <div className="space-y-6">
        {/* User Mini Card */}
        <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-emerald-600 text-white font-bold flex items-center justify-center text-sm shadow-sm">
            {user?.first_name ? user.first_name[0] : user?.username?.[0]?.toUpperCase() || 'U'}
          </div>
          <div className="min-w-0">
            <p className="text-xs font-semibold text-slate-900 truncate">
              {user?.first_name ? `${user.first_name} ${user.last_name || ''}` : user?.username}
            </p>
            <span className="inline-block px-1.5 py-0.5 text-[10px] font-semibold uppercase rounded bg-emerald-100 text-emerald-800">
              {user?.role || 'Citizen'}
            </span>
          </div>
        </div>

        {/* Navigation list */}
        <nav className="space-y-1">
          {links.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-emerald-50 text-emerald-700 font-semibold shadow-sm'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`
                }
              >
                <Icon className="w-4 h-4" />
                {item.name}
              </NavLink>
            );
          })}
        </nav>
      </div>

      {/* Footer info in sidebar */}
      <div className="pt-4 border-t border-slate-100 text-xs text-slate-400">
        <p className="font-semibold text-slate-600">Smart Community v1.0</p>
        <p>Civic Response System</p>
      </div>
    </aside>
  );
};
