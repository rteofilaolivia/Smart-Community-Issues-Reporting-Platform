import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, MessageSquare, Clock, User, ArrowUpRight, Image as ImageIcon } from 'lucide-react';
import { StatusBadge } from '../common/StatusBadge';
import { PriorityBadge } from '../common/PriorityBadge';

export const IssueCard = ({ issue }) => {
  const formattedDate = new Date(issue.created_at).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  return (
    <div className="card-container hover:border-slate-300 hover:shadow-md transition-all flex flex-col justify-between overflow-hidden group">
      <div>
        {/* Optional Image Preview */}
        {issue.image && (
          <div className="relative h-44 w-full bg-slate-100 overflow-hidden border-b border-slate-100">
            <img
              src={issue.image}
              alt={issue.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              loading="lazy"
            />
            <div className="absolute top-3 right-3">
              <PriorityBadge priority={issue.priority} />
            </div>
          </div>
        )}

        <div className="p-5">
          {/* Category & Status Bar */}
          <div className="flex items-center justify-between gap-2 mb-3">
            <span
              className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md text-xs font-semibold"
              style={{
                backgroundColor: `${issue.category_color || '#3b82f6'}15`,
                color: issue.category_color || '#2563eb',
              }}
            >
              {issue.category_name || 'Civic Issue'}
            </span>

            <StatusBadge status={issue.status} />
          </div>

          {/* Title */}
          <Link to={`/issues/${issue.id}`} className="block group-hover:text-emerald-700 transition-colors">
            <h3 className="font-bold text-base text-slate-900 line-clamp-1 mb-1.5">
              {issue.title}
            </h3>
          </Link>

          {/* Description snippet */}
          <p className="text-xs text-slate-500 line-clamp-2 mb-4 leading-relaxed">
            {issue.description}
          </p>

          {/* Location */}
          <div className="flex items-center gap-1.5 text-xs text-slate-600 mb-3 bg-slate-50 p-2 rounded-lg border border-slate-100">
            <MapPin className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
            <span className="truncate">{issue.location || 'Location specified on file'}</span>
          </div>
        </div>
      </div>

      {/* Card Footer */}
      <div className="px-5 py-3 bg-slate-50/70 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1">
            <User className="w-3.5 h-3.5 text-slate-400" />
            <span className="truncate max-w-[90px]">{issue.citizen_name || 'Citizen'}</span>
          </span>
          <span className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-slate-400" />
            {formattedDate}
          </span>
        </div>

        <Link
          to={`/issues/${issue.id}`}
          className="text-emerald-600 font-semibold hover:text-emerald-700 flex items-center gap-0.5"
        >
          Details <ArrowUpRight className="w-3.5 h-3.5" />
        </Link>
      </div>
    </div>
  );
};
