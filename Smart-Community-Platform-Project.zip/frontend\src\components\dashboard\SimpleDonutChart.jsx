import React from 'react';

const statusColorMap = {
  reported: '#3b82f6',
  under_review: '#f59e0b',
  assigned: '#a855f7',
  in_progress: '#6366f1',
  resolved: '#10b981',
  rejected: '#f43f5e',
};

export const SimpleDonutChart = ({ data = [], title = 'Issues by Status' }) => {
  if (!data || data.length === 0) {
    return (
      <div className="card-container p-6">
        <h4 className="font-bold text-sm text-slate-800 mb-4">{title}</h4>
        <div className="text-center py-8 text-xs text-slate-400">No chart data available</div>
      </div>
    );
  }

  const total = data.reduce((acc, curr) => acc + (curr.count || 0), 0);

  return (
    <div className="card-container p-6">
      <h4 className="font-bold text-sm text-slate-800 mb-5">{title}</h4>

      {/* Progress Bar Breakdown Stack */}
      <div className="h-4 w-full rounded-full bg-slate-100 overflow-hidden flex mb-6">
        {data.map((item) => {
          const pct = total > 0 ? (item.count / total) * 100 : 0;
          if (pct === 0) return null;
          return (
            <div
              key={item.status}
              title={`${item.label}: ${item.count} (${pct.toFixed(1)}%)`}
              style={{
                width: `${pct}%`,
                backgroundColor: statusColorMap[item.status] || '#94a3b8',
              }}
              className="h-full transition-all duration-500"
            />
          );
        })}
      </div>

      {/* Legend Grid */}
      <div className="grid grid-cols-2 gap-3">
        {data.map((item) => {
          const color = statusColorMap[item.status] || '#94a3b8';
          return (
            <div key={item.status} className="flex items-center gap-2 text-xs">
              <span
                className="w-3 h-3 rounded-full flex-shrink-0"
                style={{ backgroundColor: color }}
              />
              <span className="text-slate-600 truncate flex-1">{item.label}</span>
              <span className="font-bold text-slate-900">{item.count}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
