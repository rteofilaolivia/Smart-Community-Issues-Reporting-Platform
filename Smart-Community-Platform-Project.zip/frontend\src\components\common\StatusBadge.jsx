import React from 'react';
import { AlertCircle, Clock, UserCheck, PlayCircle, CheckCircle2, XCircle } from 'lucide-react';

const statusConfig = {
  reported: {
    label: 'Reported',
    bg: 'bg-blue-50 text-blue-700 border-blue-200',
    icon: AlertCircle,
  },
  under_review: {
    label: 'Under Review',
    bg: 'bg-amber-50 text-amber-700 border-amber-200',
    icon: Clock,
  },
  assigned: {
    label: 'Assigned',
    bg: 'bg-purple-50 text-purple-700 border-purple-200',
    icon: UserCheck,
  },
  in_progress: {
    label: 'In Progress',
    bg: 'bg-indigo-50 text-indigo-700 border-indigo-200',
    icon: PlayCircle,
  },
  resolved: {
    label: 'Resolved',
    bg: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    icon: CheckCircle2,
  },
  rejected: {
    label: 'Rejected',
    bg: 'bg-rose-50 text-rose-700 border-rose-200',
    icon: XCircle,
  },
};

export const StatusBadge = ({ status, size = 'sm', showIcon = true }) => {
  const config = statusConfig[status] || {
    label: status || 'Unknown',
    bg: 'bg-slate-100 text-slate-700 border-slate-200',
    icon: AlertCircle,
  };

  const Icon = config.icon;
  const sizeClasses = size === 'lg' ? 'px-3 py-1.5 text-sm gap-2' : 'px-2.5 py-0.5 text-xs gap-1.5';

  return (
    <span
      className={`inline-flex items-center font-medium rounded-full border ${config.bg} ${sizeClasses}`}
    >
      {showIcon && <Icon className={size === 'lg' ? 'w-4 h-4' : 'w-3.5 h-3.5'} />}
      <span>{config.label}</span>
    </span>
  );
};
