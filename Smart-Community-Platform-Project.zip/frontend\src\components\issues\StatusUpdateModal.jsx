import React, { useState } from 'react';
import { Modal } from '../common/Modal';
import { issueService } from '../../services/issueService';
import { useToast } from '../../context/ToastContext';

export const StatusUpdateModal = ({ isOpen, onClose, issue, onStatusUpdated }) => {
  const [status, setStatus] = useState(issue?.status || 'under_review');
  const [notes, setNotes] = useState('');
  const [resolutionNotes, setResolutionNotes] = useState('');
  const [rejectionReason, setRejectionReason] = useState('');
  const [loading, setLoading] = useState(false);
  const { success, error } = useToast();

  if (!issue) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const updated = await issueService.updateStatus(issue.id, {
        status,
        notes,
        rejection_reason: rejectionReason,
        resolution_notes: resolutionNotes,
      });
      success(`Issue #${issue.id} status updated to ${status.replace('_', ' ')}!`);
      onStatusUpdated(updated);
      onClose();
    } catch (err) {
      console.error('Failed to update status:', err);
      error(err.response?.data?.rejection_reason?.[0] || 'Failed to update issue status.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Update Status: #${issue.id}`}
      subtitle={issue.title}
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
            New Status *
          </label>
          <select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            className="input-field"
            required
          >
            <option value="reported">Reported</option>
            <option value="under_review">Under Review</option>
            <option value="assigned">Assigned</option>
            <option value="in_progress">In Progress</option>
            <option value="resolved">Resolved</option>
            <option value="rejected">Rejected</option>
          </select>
        </div>

        {status === 'resolved' && (
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Resolution Summary / Field Notes *
            </label>
            <textarea
              rows={3}
              required
              value={resolutionNotes}
              onChange={(e) => setResolutionNotes(e.target.value)}
              placeholder="Describe work completed (e.g. Pothole filled and road repaved by Team B)..."
              className="input-field"
            />
          </div>
        )}

        {status === 'rejected' && (
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Rejection Reason *
            </label>
            <textarea
              rows={3}
              required
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              placeholder="Explain why this issue cannot be processed (e.g. Duplicate ticket, Private property)..."
              className="input-field"
            />
          </div>
        )}

        <div>
          <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
            Audit Activity Log Note
          </label>
          <input
            type="text"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Optional internal comment or dispatch details..."
            className="input-field"
          />
        </div>

        <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            disabled={loading}
            className="btn-secondary"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={loading}
            className="btn-primary"
          >
            {loading ? 'Updating...' : 'Save Status Update'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
