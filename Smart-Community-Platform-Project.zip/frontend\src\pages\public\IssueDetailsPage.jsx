import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { 
  MapPin, 
  Clock, 
  User, 
  Building2, 
  CheckCircle2, 
  AlertTriangle, 
  MessageSquare, 
  Send, 
  Trash2, 
  Edit3, 
  ArrowLeft,
  Navigation,
  ShieldCheck
} from 'lucide-react';
import { issueService } from '../../services/issueService';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { StatusBadge } from '../../components/common/StatusBadge';
import { PriorityBadge } from '../../components/common/PriorityBadge';
import { LoadingSpinner } from '../../components/common/LoadingSpinner';
import { IssueTimeline } from '../../components/issues/IssueTimeline';
import { StatusUpdateModal } from '../../components/issues/StatusUpdateModal';
import { AssignModal } from '../../components/issues/AssignModal';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';

export const IssueDetailsPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, isAuthority, isAdmin, isAuthenticated } = useAuth();
  const { success, error } = useToast();

  const [issue, setIssue] = useState(null);
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [isInternalComment, setIsInternalComment] = useState(false);
  const [loading, setLoading] = useState(true);
  const [commentSubmitting, setCommentSubmitting] = useState(false);

  // Modals
  const [isStatusModalOpen, setIsStatusModalOpen] = useState(false);
  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);

  const fetchIssueDetails = async () => {
    try {
      const data = await issueService.getIssue(id);
      setIssue(data);
      setComments(data.comments || []);
    } catch (err) {
      console.error('Failed to load issue details:', err);
      error('Issue not found or could not be loaded.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchIssueDetails();
  }, [id]);

  const handleAddComment = async (e) => {
    e.preventDefault();
    if (!newComment.trim()) return;

    setCommentSubmitting(true);
    try {
      const commentData = await issueService.addComment(id, {
        text: newComment,
        is_internal: isInternalComment,
      });
      setComments([...comments, commentData]);
      setNewComment('');
      setIsInternalComment(false);
      success('Comment posted successfully!');
    } catch (err) {
      console.error('Failed to post comment:', err);
      error('Failed to submit comment. Please sign in first.');
    } finally {
      setCommentSubmitting(false);
    }
  };

  const handleDeleteIssue = async () => {
    setDeleteLoading(true);
    try {
      await issueService.deleteIssue(id);
      success('Issue ticket deleted successfully.');
      navigate('/admin/issues');
    } catch (err) {
      console.error('Failed to delete issue:', err);
      error('Failed to delete issue report.');
    } finally {
      setDeleteLoading(false);
      setIsDeleteDialogOpen(false);
    }
  };

  if (loading) {
    return <LoadingSpinner fullPage message="Loading civic issue details..." />;
  }

  if (!issue) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center space-y-4">
        <h2 className="text-xl font-bold text-slate-800">Issue Not Found</h2>
        <p className="text-xs text-slate-500">The requested report might have been removed or does not exist.</p>
        <Link to="/feed" className="btn-primary">Back to Explore Feed</Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Navigation Breadcrumb & Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <Link
          to="/feed"
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900"
        >
          <ArrowLeft className="w-4 h-4" /> Back to Explore Issues
        </Link>

        {/* Authority / Admin Actions */}
        {isAuthority && (
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => setIsStatusModalOpen(true)}
              className="btn-primary text-xs flex items-center gap-1.5"
            >
              <Edit3 className="w-3.5 h-3.5" /> Update Status
            </button>

            <button
              onClick={() => setIsAssignModalOpen(true)}
              className="btn-secondary text-xs flex items-center gap-1.5"
            >
              <Building2 className="w-3.5 h-3.5 text-emerald-600" /> Assign Dept
            </button>

            {isAdmin && (
              <button
                onClick={() => setIsDeleteDialogOpen(true)}
                className="btn-danger text-xs flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" /> Delete
              </button>
            )}
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Columns: Main Issue Content, Media, Comments */}
        <div className="lg:col-span-2 space-y-6">
          {/* Header Card */}
          <div className="card-container p-6 sm:p-8 space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-2.5">
              <span className="text-xs font-mono font-bold text-slate-400">
                Ticket #{issue.id}
              </span>
              <div className="flex items-center gap-2">
                <PriorityBadge priority={issue.priority} size="lg" />
                <StatusBadge status={issue.status} size="lg" />
              </div>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 leading-snug">
              {issue.title}
            </h1>

            {/* Category Tag */}
            <div className="flex items-center gap-2">
              <span
                className="px-3 py-1 rounded-lg text-xs font-bold"
                style={{
                  backgroundColor: `${issue.category_details?.color || '#3b82f6'}15`,
                  color: issue.category_details?.color || '#2563eb',
                }}
              >
                {issue.category_details?.name || 'Civic Infrastructure'}
              </span>
              <span className="text-xs text-slate-400">
                Submitted on {new Date(issue.created_at).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
              </span>
            </div>

            {/* Description */}
            <div className="pt-4 border-t border-slate-100">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Problem Description
              </h3>
              <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-line">
                {issue.description}
              </p>
            </div>

            {/* Resolution or Rejection Callouts */}
            {issue.status === 'resolved' && (
              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 space-y-1">
                <div className="flex items-center gap-2 font-bold text-sm text-emerald-800">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  Issue Marked Resolved
                </div>
                <p className="text-xs text-emerald-700">
                  {issue.resolution_notes || 'Municipal service work completed and verified.'}
                </p>
              </div>
            )}

            {issue.status === 'rejected' && (
              <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-900 space-y-1">
                <div className="flex items-center gap-2 font-bold text-sm text-rose-800">
                  <AlertTriangle className="w-5 h-5 text-rose-600" />
                  Ticket Closed / Rejected
                </div>
                <p className="text-xs text-rose-700">
                  Reason: {issue.rejection_reason || 'Report did not qualify for municipal work.'}
                </p>
              </div>
            )}

            {/* Photo Evidence */}
            {issue.image && (
              <div className="pt-4 border-t border-slate-100">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                  Uploaded Photo Evidence
                </h3>
                <div className="rounded-2xl overflow-hidden border border-slate-200 bg-slate-900">
                  <img
                    src={issue.image}
                    alt={issue.title}
                    className="w-full max-h-96 object-contain"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Comments & Discussion */}
          <div className="card-container p-6 sm:p-8 space-y-6">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-slate-500" />
                Community Updates & Notes ({comments.length})
              </h3>
            </div>

            {/* Comment Form */}
            {isAuthenticated ? (
              <form onSubmit={handleAddComment} className="space-y-3">
                <textarea
                  rows={3}
                  required
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder="Post an update, question, or verification note..."
                  className="input-field"
                />

                <div className="flex items-center justify-between gap-2">
                  {isAuthority ? (
                    <label className="flex items-center gap-2 text-xs font-medium text-amber-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={isInternalComment}
                        onChange={(e) => setIsInternalComment(e.target.checked)}
                        className="rounded text-amber-600 focus:ring-amber-500"
                      />
                      Internal Staff Note (Hidden from citizens)
                    </label>
                  ) : <div />}

                  <button
                    type="submit"
                    disabled={commentSubmitting}
                    className="btn-primary text-xs flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5" />
                    {commentSubmitting ? 'Posting...' : 'Post Comment'}
                  </button>
                </div>
              </form>
            ) : (
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-center">
                <p className="text-xs text-slate-600 mb-2">
                  Sign in to join the discussion on this community ticket.
                </p>
                <Link to="/login" className="btn-secondary text-xs">
                  Sign In to Comment
                </Link>
              </div>
            )}

            {/* Comments List */}
            <div className="space-y-4 pt-2">
              {comments.length === 0 ? (
                <p className="text-xs text-slate-400 text-center py-4">No comments posted yet.</p>
              ) : (
                comments.map((c) => (
                  <div
                    key={c.id}
                    className={`p-4 rounded-xl border text-xs space-y-1.5 ${
                      c.is_internal
                        ? 'bg-amber-50/70 border-amber-200'
                        : 'bg-slate-50/70 border-slate-100'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900">
                          {c.author_details?.first_name
                            ? `${c.author_details.first_name} ${c.author_details.last_name || ''}`
                            : c.author_details?.username}
                        </span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded uppercase font-semibold bg-slate-200 text-slate-700">
                          {c.author_details?.role || 'Citizen'}
                        </span>
                        {c.is_internal && (
                          <span className="text-[10px] px-1.5 py-0.5 rounded font-semibold bg-amber-200 text-amber-800">
                            Internal Staff Note
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-400">
                        {new Date(c.created_at).toLocaleString()}
                      </span>
                    </div>
                    <p className="text-slate-700 leading-relaxed">{c.text}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Location, Assignment Meta, Audit Timeline */}
        <div className="space-y-6">
          {/* Metadata Card */}
          <div className="card-container p-6 space-y-4">
            <h3 className="font-bold text-sm text-slate-900 border-b border-slate-100 pb-3">
              Ticket Metadata
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <span className="text-slate-400 font-medium block">Reported By</span>
                <span className="font-semibold text-slate-800">
                  {issue.citizen_details?.first_name
                    ? `${issue.citizen_details.first_name} ${issue.citizen_details.last_name || ''}`
                    : issue.citizen_details?.username || 'Resident'}
                </span>
              </div>

              <div>
                <span className="text-slate-400 font-medium block">Assigned Department</span>
                <span className="font-semibold text-slate-800">
                  {issue.assigned_department_details?.name || 'Pending Department Triage'}
                </span>
              </div>

              <div>
                <span className="text-slate-400 font-medium block">Assigned Field Inspector</span>
                <span className="font-semibold text-slate-800">
                  {issue.assigned_to_details?.first_name
                    ? `${issue.assigned_to_details.first_name} ${issue.assigned_to_details.last_name}`
                    : issue.assigned_to_details?.username || 'General Team Queue'}
                </span>
              </div>
            </div>
          </div>

          {/* Location Card */}
          <div className="card-container p-6 space-y-4">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-emerald-600" />
              Incident Location
            </h3>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs text-slate-700">
              <p className="font-semibold text-slate-900">{issue.location}</p>
              {issue.latitude && issue.longitude && (
                <div className="mt-2 text-[11px] text-slate-500 font-mono">
                  GPS: {issue.latitude.toFixed(5)}, {issue.longitude.toFixed(5)}
                </div>
              )}
            </div>

            {issue.latitude && issue.longitude && (
              <a
                href={`https://www.google.com/maps?q=${issue.latitude},${issue.longitude}`}
                target="_blank"
                rel="noreferrer"
                className="btn-secondary w-full text-xs flex items-center justify-center gap-1.5"
              >
                <Navigation className="w-3.5 h-3.5 text-emerald-600" />
                Open External Map Navigation
              </a>
            )}
          </div>

          {/* Timeline Audit Trail */}
          <div className="card-container p-6 space-y-4">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-1.5 border-b border-slate-100 pb-3">
              <Clock className="w-4 h-4 text-emerald-600" />
              Status History & Audit Trail
            </h3>

            <IssueTimeline activities={issue.activities} />
          </div>
        </div>
      </div>

      {/* Admin Modals */}
      <StatusUpdateModal
        isOpen={isStatusModalOpen}
        onClose={() => setIsStatusModalOpen(false)}
        issue={issue}
        onStatusUpdated={(updated) => setIssue(updated)}
      />

      <AssignModal
        isOpen={isAssignModalOpen}
        onClose={() => setIsAssignModalOpen(false)}
        issue={issue}
        onAssigned={(updated) => setIssue(updated)}
      />

      <ConfirmDialog
        isOpen={isDeleteDialogOpen}
        onClose={() => setIsDeleteDialogOpen(false)}
        onConfirm={handleDeleteIssue}
        title="Delete Issue Report"
        message="Are you sure you want to permanently delete this community report? This action cannot be reversed."
        confirmText="Delete Report"
        isLoading={deleteLoading}
      />
    </div>
  );
};
