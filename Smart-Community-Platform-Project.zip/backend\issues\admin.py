from django.contrib import admin
from .models import IssueCategory, Issue, IssueComment, IssueActivityLog

class IssueCommentInline(admin.TabularInline):
    model = IssueComment
    extra = 0
    readonly_fields = ('author', 'created_at')

class IssueActivityLogInline(admin.TabularInline):
    model = IssueActivityLog
    extra = 0
    readonly_fields = ('performed_by', 'action', 'old_status', 'new_status', 'notes', 'created_at')

@admin.register(IssueCategory)
class IssueCategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'slug', 'color', 'default_department', 'is_active')
    prepopulated_fields = {'slug': ('name',)}
    list_filter = ('is_active',)
    search_fields = ('name', 'description')

@admin.register(Issue)
class IssueAdmin(admin.ModelAdmin):
    list_display = ('id', 'title', 'category', 'status', 'priority', 'citizen', 'assigned_department', 'created_at')
    list_filter = ('status', 'priority', 'category', 'assigned_department', 'created_at')
    search_fields = ('title', 'description', 'location', 'citizen__username', 'citizen__email')
    inlines = [IssueCommentInline, IssueActivityLogInline]

@admin.register(IssueComment)
class IssueCommentAdmin(admin.ModelAdmin):
    list_display = ('id', 'issue', 'author', 'is_internal', 'created_at')
    list_filter = ('is_internal', 'created_at')
    search_fields = ('text', 'author__username')

@admin.register(IssueActivityLog)
class IssueActivityLogAdmin(admin.ModelAdmin):
    list_display = ('id', 'issue', 'performed_by', 'action', 'old_status', 'new_status', 'created_at')
    list_filter = ('old_status', 'new_status', 'created_at')
