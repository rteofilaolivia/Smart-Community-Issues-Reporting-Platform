from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import IssueViewSet, IssueCategoryViewSet

router = DefaultRouter()
router.register(r'categories', IssueCategoryViewSet, basename='issue-category')
router.register(r'issues', IssueViewSet, basename='issue')

urlpatterns = [
    path('', include(router.urls)),
]
