from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import permissions, status
from django.db.models import Count, Q
from django.contrib.auth import get_user_model
from issues.models import Issue, IssueCategory, IssueActivityLog
from issues.serializers import IssueActivityLogSerializer, IssueListSerializer
from accounts.permissions import IsStaffOrAdmin

User = get_user_model()

class OverviewStatsView(APIView):
    """
    Returns public high-level civic metrics or admin overview depending on user credentials.
    """
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        total_issues = Issue.objects.count()
        reported_issues = Issue.objects.filter(status=Issue.Status.REPORTED).count()
        under_review_issues = Issue.objects.filter(status=Issue.Status.UNDER_REVIEW).count()
        assigned_issues = Issue.objects.filter(status=Issue.Status.ASSIGNED).count()
        in_progress_issues = Issue.objects.filter(status=Issue.Status.IN_PROGRESS).count()
        resolved_issues = Issue.objects.filter(status=Issue.Status.RESOLVED).count()
        rejected_issues = Issue.objects.filter(status=Issue.Status.REJECTED).count()

        pending_total = reported_issues + under_review_issues + assigned_issues

        resolution_rate = round((resolved_issues / total_issues * 100), 1) if total_issues > 0 else 0

        data = {
            'total_issues': total_issues,
            'reported_issues': reported_issues,
            'under_review_issues': under_review_issues,
            'assigned_issues': assigned_issues,
            'in_progress_issues': in_progress_issues,
            'resolved_issues': resolved_issues,
            'rejected_issues': rejected_issues,
            'pending_issues': pending_total,
            'resolution_rate': resolution_rate,
        }

        # Include admin metrics if requested by authority
        if request.user.is_authenticated and request.user.is_authority:
            data['total_users'] = User.objects.count()
            data['total_citizens'] = User.objects.filter(role=User.Role.CITIZEN).count()
            data['total_staff'] = User.objects.filter(role=User.Role.STAFF).count()
            data['total_admins'] = User.objects.filter(role=User.Role.ADMIN).count()

        return Response(data)


class UserStatsView(APIView):
    """
    Returns personal metrics for the logged-in citizen.
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        user = request.user
        user_issues = Issue.objects.filter(citizen=user)
        total = user_issues.count()
        pending = user_issues.filter(status__in=[Issue.Status.REPORTED, Issue.Status.UNDER_REVIEW, Issue.Status.ASSIGNED]).count()
        in_progress = user_issues.filter(status=Issue.Status.IN_PROGRESS).count()
        resolved = user_issues.filter(status=Issue.Status.RESOLVED).count()
        rejected = user_issues.filter(status=Issue.Status.REJECTED).count()

        recent_reports = user_issues.order_by('-created_at')[:5]
        recent_serializer = IssueListSerializer(recent_reports, many=True, context={'request': request})

        return Response({
            'total_reports': total,
            'pending_reports': pending,
            'in_progress_reports': in_progress,
            'resolved_reports': resolved,
            'rejected_reports': rejected,
            'recent_reports': recent_serializer.data,
        })


class CategoryBreakdownView(APIView):
    """
    Breakdown of issues aggregated by category.
    """
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        categories = IssueCategory.objects.annotate(
            total_issues=Count('issues'),
            resolved_issues=Count('issues', filter=Q(issues__status=Issue.Status.RESOLVED)),
            open_issues=Count('issues', filter=~Q(issues__status__in=[Issue.Status.RESOLVED, Issue.Status.REJECTED]))
        ).values('id', 'name', 'slug', 'icon', 'color', 'total_issues', 'resolved_issues', 'open_issues')

        return Response(list(categories))


class StatusBreakdownView(APIView):
    """
    Breakdown of issues aggregated by status with percentages.
    """
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        total = Issue.objects.count()
        status_counts = Issue.objects.values('status').annotate(count=Count('id'))
        
        status_dict = {item['status']: item['count'] for item in status_counts}
        result = []

        for code, label in Issue.Status.choices:
            count = status_dict.get(code, 0)
            percentage = round((count / total * 100), 1) if total > 0 else 0
            result.append({
                'status': code,
                'label': label,
                'count': count,
                'percentage': percentage,
            })

        return Response(result)


class RecentActivityFeedView(APIView):
    """
    Recent civic timeline activities across all issues.
    """
    permission_classes = [IsStaffOrAdmin]

    def get(self, request):
        activities = IssueActivityLog.objects.select_related('issue', 'performed_by').order_by('-created_at')[:15]
        serializer = IssueActivityLogSerializer(activities, many=True)
        return Response(serializer.data)
