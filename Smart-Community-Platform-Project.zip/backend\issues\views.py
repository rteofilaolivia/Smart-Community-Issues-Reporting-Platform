from rest_framework import viewsets, permissions, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser
from django.utils import timezone
from django.db.models import Q
from accounts.permissions import IsAdminUserCustom, IsStaffOrAdmin, IsOwnerOrAdmin
from accounts.models import Department, User
from .models import Issue, IssueCategory, IssueComment, IssueActivityLog
from .serializers import (
    IssueCategorySerializer,
    IssueListSerializer,
    IssueDetailSerializer,
    IssueCreateUpdateSerializer,
    IssueStatusUpdateSerializer,
    IssueAssignSerializer,
    IssueCommentSerializer,
    IssueActivityLogSerializer,
)
from notifications.models import Notification

class IssueCategoryViewSet(viewsets.ModelViewSet):
    """
    API endpoint for viewing and managing issue categories.
    """
    queryset = IssueCategory.objects.all()
    serializer_class = IssueCategorySerializer
    lookup_field = 'slug'

    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            return [permissions.AllowAny()]
        return [IsAdminUserCustom()]


class IssueViewSet(viewsets.ModelViewSet):
    """
    Core API endpoint for community issues lifecycle.
    """
    queryset = Issue.objects.all().select_related('category', 'citizen', 'assigned_department', 'assigned_to')
    parser_classes = [MultiPartParser, FormParser, JSONParser]
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['title', 'description', 'location', 'citizen__username', 'citizen__first_name', 'citizen__last_name']
    ordering_fields = ['created_at', 'updated_at', 'priority', 'status']
    ordering = ['-created_at']

    def get_serializer_class(self):
        if self.action == 'list':
            return IssueListSerializer
        elif self.action == 'retrieve':
            return IssueDetailSerializer
        elif self.action in ['create', 'update', 'partial_update']:
            return IssueCreateUpdateSerializer
        return IssueDetailSerializer

    def get_permissions(self):
        if self.action in ['list', 'retrieve', 'comments']:
            return [permissions.AllowAny()]
        elif self.action in ['create', 'my_reports']:
            return [permissions.IsAuthenticated()]
        elif self.action in ['update_status', 'assign']:
            return [IsStaffOrAdmin()]
        elif self.action == 'destroy':
            return [IsAdminUserCustom()]
        return [IsOwnerOrAdmin()]

    def get_queryset(self):
        queryset = super().get_queryset()
        params = self.request.query_params

        # Filter by category
        category = params.get('category')
        if category:
            if category.isdigit():
                queryset = queryset.filter(category_id=category)
            else:
                queryset = queryset.filter(category__slug=category)

        # Filter by status
        issue_status = params.get('status')
        if issue_status:
            queryset = queryset.filter(status=issue_status)

        # Filter by priority
        priority = params.get('priority')
        if priority:
            queryset = queryset.filter(priority=priority)

        # Filter by department
        department = params.get('department')
        if department:
            queryset = queryset.filter(assigned_department_id=department)

        # Filter by location query
        location = params.get('location')
        if location:
            queryset = queryset.filter(location__icontains=location)

        return queryset

    def perform_create(self, serializer):
        issue = serializer.save(citizen=self.request.user)
        # Log initial creation in audit history
        IssueActivityLog.objects.create(
            issue=issue,
            performed_by=self.request.user,
            action='Issue reported by resident',
            new_status=issue.status,
            notes='Initial civic report submission.'
        )

    @action(detail=False, methods=['get'], permission_classes=[permissions.IsAuthenticated])
    def my_reports(self, request):
        """
        List all issues reported by the authenticated citizen.
        """
        user_issues = self.get_queryset().filter(citizen=request.user)
        page = self.paginate_queryset(user_issues)
        if page is not None:
            serializer = IssueListSerializer(page, many=True, context={'request': request})
            return self.get_paginated_response(serializer.data)
        serializer = IssueListSerializer(user_issues, many=True, context={'request': request})
        return Response(serializer.data)

    @action(detail=True, methods=['post'], permission_classes=[IsStaffOrAdmin])
    def update_status(self, request, pk=None):
        """
        Update issue status, log the activity, and send a notification to the reporting citizen.
        """
        issue = self.get_object()
        serializer = IssueStatusUpdateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        old_status = issue.status
        new_status = serializer.validated_data['status']
        notes = serializer.validated_data.get('notes', '')
        rejection_reason = serializer.validated_data.get('rejection_reason', '')
        resolution_notes = serializer.validated_data.get('resolution_notes', '')

        issue.status = new_status
        if new_status == Issue.Status.RESOLVED:
            issue.resolved_at = timezone.now()
            if resolution_notes:
                issue.resolution_notes = resolution_notes
        elif new_status == Issue.Status.REJECTED:
            if rejection_reason:
                issue.rejection_reason = rejection_reason
        
        issue.save()

        # Audit activity record
        action_text = f"Status updated from '{old_status.replace('_', ' ').title()}' to '{new_status.replace('_', ' ').title()}'"
        log_notes = notes or rejection_reason or resolution_notes
        IssueActivityLog.objects.create(
            issue=issue,
            performed_by=request.user,
            action=action_text,
            old_status=old_status,
            new_status=new_status,
            notes=log_notes
        )

        # Notify the citizen
        Notification.objects.create(
            recipient=issue.citizen,
            issue=issue,
            title=f"Status Update on #{issue.id}: {issue.title[:30]}",
            message=f"Your reported issue status has been updated to '{issue.get_status_display()}'. {log_notes}".strip(),
            notification_type=Notification.NotificationType.STATUS_CHANGE
        )

        return Response(IssueDetailSerializer(issue, context={'request': request}).data)

    @action(detail=True, methods=['post'], permission_classes=[IsStaffOrAdmin])
    def assign(self, request, pk=None):
        """
        Assign issue to a municipal department and/or specific staff member.
        """
        issue = self.get_object()
        serializer = IssueAssignSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        department = serializer.validated_data.get('assigned_department')
        assigned_to = serializer.validated_data.get('assigned_to')
        notes = serializer.validated_data.get('notes', '')

        issue.assigned_department = department
        issue.assigned_to = assigned_to
        if issue.status == Issue.Status.REPORTED:
            issue.status = Issue.Status.ASSIGNED
        issue.save()

        dept_name = department.name if department else "Unassigned"
        staff_name = assigned_to.get_full_name() or assigned_to.username if assigned_to else "Department Queue"
        action_text = f"Assigned to {dept_name} ({staff_name})"

        IssueActivityLog.objects.create(
            issue=issue,
            performed_by=request.user,
            action=action_text,
            new_status=issue.status,
            notes=notes
        )

        # Notify citizen
        Notification.objects.create(
            recipient=issue.citizen,
            issue=issue,
            title=f"Issue #{issue.id} Assigned to {dept_name}",
            message=f"Your issue has been assigned to the {dept_name} team for investigation.",
            notification_type=Notification.NotificationType.ASSIGNMENT
        )

        # Notify assigned staff member if designated
        if assigned_to and assigned_to != request.user:
            Notification.objects.create(
                recipient=assigned_to,
                issue=issue,
                title=f"New Task Assigned: #{issue.id} - {issue.title[:30]}",
                message=f"You have been assigned to investigate this issue located at {issue.location}.",
                notification_type=Notification.NotificationType.ASSIGNMENT
            )

        return Response(IssueDetailSerializer(issue, context={'request': request}).data)

    @action(detail=True, methods=['get', 'post'], permission_classes=[permissions.IsAuthenticatedOrReadOnly])
    def comments(self, request, pk=None):
        """
        Retrieve or add comments to a civic issue.
        """
        issue = self.get_object()

        if request.method == 'GET':
            comments = issue.comments.all()
            if not request.user or not (request.user.is_authenticated and request.user.is_authority):
                comments = comments.filter(is_internal=False)
            serializer = IssueCommentSerializer(comments, many=True, context={'request': request})
            return Response(serializer.data)

        elif request.method == 'POST':
            if not request.user.is_authenticated:
                return Response({'detail': 'Authentication required to post comments.'}, status=status.HTTP_401_UNAUTHORIZED)

            text = request.data.get('text', '').strip()
            if not text:
                return Response({'text': ['Comment text cannot be empty.']}, status=status.HTTP_400_BAD_REQUEST)

            is_internal = request.data.get('is_internal', False)
            if is_internal and not request.user.is_authority:
                is_internal = False  # Citizens cannot make internal staff notes

            comment = IssueComment.objects.create(
                issue=issue,
                author=request.user,
                text=text,
                is_internal=is_internal
            )

            # If staff commented publicly, notify the citizen
            if not is_internal and request.user != issue.citizen:
                Notification.objects.create(
                    recipient=issue.citizen,
                    issue=issue,
                    title=f"New Official Comment on Issue #{issue.id}",
                    message=f"{request.user.get_full_name() or request.user.username} commented: {text[:80]}...",
                    notification_type=Notification.NotificationType.COMMENT
                )

            return Response(IssueCommentSerializer(comment, context={'request': request}).data, status=status.HTTP_201_CREATED)
