import React from 'react';
import { CheckCircle2, Clock, PlayCircle, ShieldCheck, UserCheck, AlertTriangle } from 'lucide-react';

export const IssueTimeline = ({ activities = [] }) => {
  if (!activities || activities.length === 0) {
    return (
      <div className="py-6 text-center text-xs text-slate-400">
        No recorded activity updates yet.
      </div>
    );
  }

  const getIcon = (action = '', status = '') => {
    if (status === 'resolved' || action.toLowerCase().includes('resolved')) {
      return <CheckCircle2 className="w-4 h-4 text-emerald-600" />;
    }
    if (status === 'in_progress' || action.toLowerCase().includes('in progress')) {
      return <PlayCircle className="w-4 h-4 text-indigo-600" />;
    }
    if (status === 'assigned' || action.toLowerCase().includes('assigned')) {
      return <UserCheck className="w-4 h-4 text-purple-600" />;
    }
    if (status === 'rejected' || action.toLowerCase().includes('rejected')) {
      return <AlertTriangle className="w-4 h-4 text-rose-600" />;
    }
    return <Clock className="w-4 h-4 text-blue-600" />;
  };

  return (
    <div className="relative pl-6 space-y-6 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
      {activities.map((activity, index) => {
        const date = new Date(activity.created_at).toLocaleString('en-US', {
          month: 'short',
          day: 'numeric',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
        });

        return (
          <div key={activity.id || index} className="relative group">
            {/* Timeline node */}
            <div className="absolute -left-6 top-0.5 w-4 h-4 rounded-full bg-white border-2 border-slate-300 flex items-center justify-center group-hover:border-emerald-500 transition-colors">
              <span className="w-1.5 h-1.5 rounded-full bg-slate-400 group-hover:bg-emerald-500" />
            </div>

            <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-200/70">
              <div className="flex items-center justify-between gap-2 mb-1">
                <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  {getIcon(activity.action, activity.new_status)}
                  {activity.action}
                </span>
                <span className="text-[11px] text-slate-400">{date}</span>
              </div>

              <div className="text-xs text-slate-500 flex items-center gap-1.5 mb-1">
                <span>By:</span>
                <span className="font-semibold text-slate-700">{activity.performed_by_name}</span>
              </div>

              {activity.notes && (
                <p className="text-xs text-slate-600 bg-white p-2.5 rounded-lg border border-slate-100 mt-2 italic">
                  "{activity.notes}"
                </p>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
};
