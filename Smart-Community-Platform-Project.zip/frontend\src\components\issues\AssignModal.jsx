import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import { issueService } from '../../services/issueService';
import { authService } from '../../services/authService';
import { useToast } from '../../context/ToastContext';

export const AssignModal = ({ isOpen, onClose, issue, onAssigned }) => {
  const [departments, setDepartments] = useState([]);
  const [staffUsers, setStaffUsers] = useState([]);
  const [selectedDept, setSelectedDept] = useState(issue?.assigned_department || '');
  const [selectedStaff, setSelectedStaff] = useState(issue?.assigned_to || '');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const { success, error } = useToast();

  useEffect(() => {
    if (isOpen) {
      const fetchData = async () => {
        try {
          const depts = await authService.getDepartments();
          setDepartments(depts);
          const users = await authService.getUsers({ role: 'staff' });
          setStaffUsers(users.results || users);
        } catch (err) {
          console.error('Failed to load assign options:', err);
        }
      };
      fetchData();
      setSelectedDept(issue?.assigned_department || '');
      setSelectedStaff(issue?.assigned_to || '');
    }
  }, [isOpen, issue]);

  if (!issue) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const updated = await issueService.assignIssue(issue.id, {
        assigned_department: selectedDept || null,
        assigned_to: selectedStaff || null,
        notes,
      });
      success(`Issue #${issue.id} successfully assigned!`);
      onAssigned(updated);
      onClose();
    } catch (err) {
      console.error('Failed to assign issue:', err);
      error('Failed to assign issue.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Assign Issue: #${issue.id}`}
      subtitle={issue.title}
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
            Municipal Department
          </label>
          <select
            value={selectedDept}
            onChange={(e) => setSelectedDept(e.target.value)}
            className="input-field"
          >
            <option value="">-- Select Responsible Department --</option>
            {departments.map((dept) => (
              <option key={dept.id} value={dept.id}>
                {dept.name} ({dept.code})
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
            Specific Staff / Field Inspector
          </label>
          <select
            value={selectedStaff}
            onChange={(e) => setSelectedStaff(e.target.value)}
            className="input-field"
          >
            <option value="">-- Assign to General Department Queue --</option>
            {staffUsers.map((staff) => (
              <option key={staff.id} value={staff.id}>
                {staff.first_name ? `${staff.first_name} ${staff.last_name}` : staff.username} ({staff.department_details?.name || 'Staff'})
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
            Assignment Dispatch Instructions
          </label>
          <textarea
            rows={2}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Special instructions or timeline expectations..."
            className="input-field"
          />
        </div>

        <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            disabled={loading}
            className="btn-secondary"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={loading}
            className="btn-primary"
          >
            {loading ? 'Assigning...' : 'Confirm Assignment'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
