from rest_framework import permissions

class IsAdminUserCustom(permissions.BasePermission):
    """
    Allows access only to Admin users.
    """
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_platform_admin)


class IsStaffOrAdmin(permissions.BasePermission):
    """
    Allows access to Municipal Staff or Admins.
    """
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_authority)


class IsOwnerOrAdmin(permissions.BasePermission):
    """
    Object-level permission to allow owners of an object or Admins to edit it.
    """
    def has_object_permission(self, request, view, obj):
        if not request.user or not request.user.is_authenticated:
            return False
        if request.user.is_platform_admin:
            return True
        # Check if obj has citizen or user attribute
        owner = getattr(obj, 'citizen', None) or getattr(obj, 'user', None) or getattr(obj, 'author', None)
        return owner == request.user


class IsOwnerOrReadOnly(permissions.BasePermission):
    """
    Allows read-only access to anyone, but modifications only to owner or admin.
    """
    def has_object_permission(self, request, view, obj):
        if request.method in permissions.SAFE_METHODS:
            return True
        if not request.user or not request.user.is_authenticated:
            return False
        if request.user.is_platform_admin:
            return True
        owner = getattr(obj, 'citizen', None) or getattr(obj, 'user', None) or getattr(obj, 'author', None)
        return owner == request.user
