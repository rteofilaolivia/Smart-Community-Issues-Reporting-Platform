import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  PlusCircle, 
  FileText, 
  Clock, 
  CheckCircle2, 
  PlayCircle, 
  AlertCircle, 
  ArrowRight,
  TrendingUp
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { analyticsService } from '../../services/analyticsService';
import { StatCard } from '../../components/dashboard/StatCard';
import { StatusBadge } from '../../components/common/StatusBadge';
import { PriorityBadge } from '../../components/common/PriorityBadge';
import { LoadingSpinner } from '../../components/common/LoadingSpinner';

export const UserDashboardPage = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState({
    total_reports: 0,
    pending_reports: 0,
    in_progress_reports: 0,
    resolved_reports: 0,
    recent_reports: [],
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadUserStats = async () => {
      try {
        const data = await analyticsService.getUserStats();
        setStats(data);
      } catch (err) {
        console.error('Failed to load citizen dashboard data:', err);
      } finally {
        setLoading(false);
      }
    };
    loadUserStats();
  }, []);

  if (loading) {
    return <LoadingSpinner fullPage message="Loading your civic dashboard..." />;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Welcome Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-gradient-to-r from-emerald-800 to-teal-700 rounded-3xl p-6 sm:p-8 text-white shadow-md">
        <div className="space-y-1">
          <span className="text-xs font-semibold uppercase tracking-wider text-emerald-200">
            Resident Control Center
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Hello, {user?.first_name || user?.username}!
          </h1>
          <p className="text-xs sm:text-sm text-emerald-100 max-w-xl">
            Track your submitted civic reports, inspect real-time progress from local authorities, or report a new problem in your community.
          </p>
        </div>

        <Link
          to="/report"
          className="btn-primary bg-white text-emerald-900 hover:bg-emerald-50 active:bg-emerald-100 font-bold text-sm shadow-md flex items-center gap-2 self-start sm:self-auto"
        >
          <PlusCircle className="w-4 h-4 text-emerald-700" />
          Report New Issue
        </Link>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Reports Submitted"
          value={stats.total_reports}
          icon={FileText}
          color="slate"
        />
        <StatCard
          title="Under Review / Pending"
          value={stats.pending_reports}
          icon={Clock}
          color="amber"
        />
        <StatCard
          title="In Active Progress"
          value={stats.in_progress_reports}
          icon={PlayCircle}
          color="blue"
        />
        <StatCard
          title="Successfully Resolved"
          value={stats.resolved_reports}
          icon={CheckCircle2}
          color="emerald"
        />
      </div>

      {/* Recent Personal Reports Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-base text-slate-900">Your Recent Reports</h3>
            <p className="text-xs text-slate-500">Latest tickets filed from your account</p>
          </div>
          <Link
            to="/my-reports"
            className="text-xs font-semibold text-emerald-600 hover:text-emerald-700 flex items-center gap-1"
          >
            View All ({stats.total_reports}) <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {stats.recent_reports.length === 0 ? (
          <div className="card-container p-8 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
              <FileText className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-sm text-slate-800">No reports submitted yet</h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Notice a pothole, broken streetlight, or garbage buildup in your area? Help your community by reporting it today.
            </p>
            <Link to="/report" className="btn-primary text-xs inline-flex mt-2">
              Submit Your First Report
            </Link>
          </div>
        ) : (
          <div className="card-container overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-600">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-700 uppercase font-semibold text-[11px]">
                  <tr>
                    <th className="px-4 py-3">Ticket ID</th>
                    <th className="px-4 py-3">Title</th>
                    <th className="px-4 py-3">Category</th>
                    <th className="px-4 py-3">Location</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3">Submitted</th>
                    <th className="px-4 py-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {stats.recent_reports.map((report) => (
                    <tr key={report.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="px-4 py-3.5 font-bold text-slate-900">#{report.id}</td>
                      <td className="px-4 py-3.5 font-semibold text-slate-900 max-w-xs truncate">
                        {report.title}
                      </td>
                      <td className="px-4 py-3.5">
                        <span
                          className="px-2 py-0.5 rounded text-[11px] font-medium"
                          style={{
                            backgroundColor: `${report.category_color || '#3b82f6'}15`,
                            color: report.category_color || '#2563eb',
                          }}
                        >
                          {report.category_name}
                        </span>
                      </td>
                      <td className="px-4 py-3.5 truncate max-w-[150px]">{report.location}</td>
                      <td className="px-4 py-3.5">
                        <StatusBadge status={report.status} />
                      </td>
                      <td className="px-4 py-3.5 text-slate-400">
                        {new Date(report.created_at).toLocaleDateString()}
                      </td>
                      <td className="px-4 py-3.5 text-right">
                        <Link
                          to={`/issues/${report.id}`}
                          className="text-emerald-600 font-semibold hover:text-emerald-700"
                        >
                          Track Issue
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
