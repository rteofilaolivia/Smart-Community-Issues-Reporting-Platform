from django.urls import path
from .views import (
    OverviewStatsView,
    UserStatsView,
    CategoryBreakdownView,
    StatusBreakdownView,
    RecentActivityFeedView,
)

urlpatterns = [
    path('overview/', OverviewStatsView.as_view(), name='analytics_overview'),
    path('user-stats/', UserStatsView.as_view(), name='analytics_user_stats'),
    path('by-category/', CategoryBreakdownView.as_view(), name='analytics_by_category'),
    path('by-status/', StatusBreakdownView.as_view(), name='analytics_by_status'),
    path('activity-feed/', RecentActivityFeedView.as_view(), name='analytics_activity_feed'),
]
