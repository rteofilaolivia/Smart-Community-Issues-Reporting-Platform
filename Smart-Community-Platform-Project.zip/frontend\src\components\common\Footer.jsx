import React from 'react';
import { Link } from 'react-router-dom';
import { Building2, Shield, Heart, ExternalLink, PhoneCall } from 'lucide-react';

export const Footer = () => {
  return (
    <footer className="bg-slate-900 text-slate-400 text-sm mt-auto border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand Col */}
          <div className="space-y-4 md:col-span-1">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center text-white">
                <Building2 className="w-4 h-4" />
              </div>
              <span className="font-bold text-white text-base">Smart Community</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Civic issue tracking & municipal collaboration platform connecting residents directly with local authorities.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-xs font-semibold text-white uppercase tracking-wider mb-3">
              Citizen Tools
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <Link to="/report" className="hover:text-white transition-colors">
                  Report an Issue
                </Link>
              </li>
              <li>
                <Link to="/feed" className="hover:text-white transition-colors">
                  Explore Community Issues
                </Link>
              </li>
              <li>
                <Link to="/my-reports" className="hover:text-white transition-colors">
                  Track My Reports
                </Link>
              </li>
              <li>
                <Link to="/profile" className="hover:text-white transition-colors">
                  Account Profile
                </Link>
              </li>
            </ul>
          </div>

          {/* Civic Authorities */}
          <div>
            <h4 className="text-xs font-semibold text-white uppercase tracking-wider mb-3">
              Municipal Services
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <Link to="/admin/dashboard" className="hover:text-white transition-colors">
                  Authority Control Center
                </Link>
              </li>
              <li>
                <Link to="/admin/issues" className="hover:text-white transition-colors">
                  Department Triage
                </Link>
              </li>
              <li>
                <Link to="/admin/analytics" className="hover:text-white transition-colors">
                  Resolution Metrics
                </Link>
              </li>
              <li>
                <a href="/api/docs/" target="_blank" rel="noreferrer" className="hover:text-white transition-colors flex items-center gap-1">
                  REST API Docs (Swagger) <ExternalLink className="w-3 h-3" />
                </a>
              </li>
            </ul>
          </div>

          {/* Emergency & Helpline */}
          <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/50">
            <h4 className="text-xs font-semibold text-white uppercase tracking-wider mb-2 flex items-center gap-1.5 text-rose-400">
              <PhoneCall className="w-3.5 h-3.5" /> Emergency Hotlines
            </h4>
            <p className="text-xs text-slate-300 mb-2">
              For immediate life hazards, gas leaks, or fallen live wires, please contact:
            </p>
            <p className="text-sm font-bold text-white">Emergency Services: 911 / 112</p>
            <p className="text-xs text-emerald-400 mt-1">Civic Helpline: 311 (24/7)</p>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} Smart Community Platform. Built with Django & React.</p>
          <div className="flex items-center gap-6">
            <span>Clean Civic Tech</span>
            <span>Open Data Standard</span>
            <span className="flex items-center gap-1">
              Built for Communities <Heart className="w-3 h-3 text-rose-500 fill-rose-500" />
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
